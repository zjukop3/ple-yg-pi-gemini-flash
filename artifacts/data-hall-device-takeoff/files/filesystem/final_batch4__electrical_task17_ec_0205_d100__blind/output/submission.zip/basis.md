# Basis of Estimate

Initial draft.