```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 142500.0,
      "improved_cost_usd": 77916.48
    },
    "CR-P2": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 158000.0,
      "improved_cost_usd": 88012.27
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 32729.45,
      "improved_cost_usd": 49500.0
    },
    "CR-P4": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 61623.0,
      "improved_cost_usd": 45880.92
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 16774.35,
      "improved_cost_usd": 42000.0
    },
    "CR-P6": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 148200.0,
      "improved_cost_usd": 81939.1
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 423252.57,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-01N Foundation Design 2005 (Cancelled predecessor volume)",
    "UFC 3-220-10N Soil Mechanics 2005 (Cancelled predecessor volume)",
    "AV-CR-2604 Basis of Design Structural Rev 1 (Superseded by Rev 3)",
    "AV-CR-2604 Geotechnical Addendum 1 (Superseded by GDR Rev 2)",
    "NOAA NCEI AFI return periods 1951-1980 (Superseded by 1981-2010 normals)",
    "Adjacent Parcel Report Broadview Commons 2023 (Information only, different property per RFI-013)",
    "FHWA GEC 6 Shallow Foundations for Bridges (Written for highway bridges, different class of structure)",
    "EM 1110-2-2104 Table 3-1 load factors (Hydraulic structures only, excluded by Load Combination Memo)"
  ]
}
```

# Cattail Run Data Campus — Phase 1 Foundation Package Design Basis

## 1. Criteria That Govern and Set-Aside Documents
The structural and geotechnical foundation design for Phase 1 (Building Pads `CR-P1` through `CR-P6`) is governed by:
* **Geotechnical Engineering**: UFC 3-220-01 (Change 3, 1 July 2025) and UFC 3-220-20 (Foundations and Earth Structures, DM 7.2, 16 January 2025).
* **Structural Concrete**: UFC 3-301-01 (Structural Engineering, Change 4, 2023), UFGS 03 30 00 (Cast-in-Place Concrete, Change 10, August 2025), and ACI 318.
* **Earthwork and Retaining Structures**: UFGS 31 00 00 and USACE EM 1110-2-2502.
* **Ground Modification**: FHWA GEC 13 Volume 1 (Ground Modification Methods, 2017).
* **Owner & Jurisdictional Directives**: Basis of Design Structural Rev 3, Loudoun County AHJ Amendment Letter LC-BD-26-0774, and the AV-CR-2604 RFI Log.

### Documents Reviewed and Set Aside
1. **UFC 3-220-01N (2005)**: Cancelled predecessor standard for foundation design; set aside in favor of live criteria UFC 3-220-01 and UFC 3-220-20.
2. **UFC 3-220-10N (2005)**: Cancelled predecessor standard for soil mechanics; set aside.
3. **AV-CR-2604 Basis of Design Structural Rev 1**: Superseded in its entirety by Revision 3 per Section 1 of Rev 3.
4. **AV-CR-2604 Geotechnical Addendum 1**: Superseded by Geotechnical Data Report Revision 2.
5. **NOAA NCEI AFI 1951-1980 Return Period Tables**: Superseded by the current 1981-2010 normals period product per AHJ Letter Amendment 3 and RFI-007.
6. **Adjacent Parcel Report Broadview Commons (2023)**: Pertains to a separate property; set aside for information only per RFI-013.
7. **FHWA GEC 6 (Shallow Foundations for Bridges)**: Written specifically for highway bridge substructures; set aside in favor of building criteria UFC 3-220-01 and UFC 3-220-20.
8. **EM 1110-2-2104 Table 3-1**: Contains load factors for hydraulic civil works structures; set aside per Load Combination Memorandum Section 3.

---

## 2. Bearing Capacity, Settlement Methods, and Factors of Safety

### Bearing Capacity Methods
In accordance with UFC 3-220-01 paragraph 2-4.7.1, site-specific ultimate bearing capacity was evaluated using three widely accepted methods: Meyerhof (1963), Hansen (1970), and Vesic (1973) general bearing capacity equations (detailed in EM 1110-1-1905 Chapter 4 and UFC 3-220-20 Section 5-3.1).
* Surcharge term accounts for foundation embedment D = 42 in (3.5 ft).
* Effective unit weight was corrected for groundwater position using EM 1110-1-1905 Equation 1-6 / UFC 3-220-20 Figure 5-6 when the water table is within failure depth H below the footing soffit.
* Per RFI-021, the least of the three methods was adopted for design allowable bearing capacity, providing a safe, conservative allowable pressure.

### Basis of Factors of Safety
Minimum factors of safety on bearing capacity were assigned strictly from UFC 3-220-01 Table 2-3 based on building occupancy classification from Basis of Design Rev 3 Section 2:
* **Light Industrial, Public** (`CR-P1`, `CR-P2`, `CR-P3`, `CR-P6`): FS = 3.5.
* **Apartments, Office** (`CR-P4`): FS = 3.0.
* **Warehouse** (`CR-P5`): FS = 2.5 (no super-flat floor specified).

### Settlement Analysis Method
Per RFI-019 and FHWA GEC 13 Volume 1 Equation 5-14, settlement was computed using **Layered Elastic Compression**:
* Integrated to a depth of max(4B, 40 ft) below the footing soffit.
* Discretised into uniform 0.25-ft layers, evaluating the 2V:1H net stress increment at each layer mid-height.
* Layer compressions summed using the pad-specific elastic moduli from Section 2 of Geotechnical Data Report Rev 2.
* For improved footings, the two-layer method was applied: upper zone compression `s_uz = q_g / (144 * kg)` and lower zone compression `s_lz = sum (delta_sigma * dz / Es)` for z from treatment depth to z_max.

---

## 3. Tolerable Movement Criteria
Per UFC 3-220-01 paragraph 2-4.7.1:
* **Total Post-Construction Settlement**: Maximum allowable is 1.0 inch (25.4 mm).
* **Differential Settlement / Angular Distortion**: Limited to an angular distortion `delta_s / L <= 1/500` (0.002) between any two adjacent foundation units.
* Any competing or less restrictive criteria (such as presumptive settlement guidelines or bridge tolerances) were rejected.

---

## 4. Ground Improvement Design Parameters
All rammed aggregate pier parameters are established from governing contract documents and the specialty subcontractor budget proposal:
* **Pier Diameter**: 30 inches (2.5 ft) installed (Kettleridge Budget Proposal Section 2).
* **Stress Concentration Ratio (ns)**: 10.0, governing value for structure foundation support under rigid footings per FHWA GEC 13 Volume 1 Section 4.2.2 / Page 5-43 and RFI-011.
* **Design Stiffness Modulus (kg)**: Pre-production tested values per pad (Kettleridge Section 3):
  * CR-P1: 165 pci
  * CR-P2: 140 pci
  * CR-P3: 210 pci
  * CR-P4: 195 pci
  * CR-P5: 230 pci
  * CR-P6: 155 pci
* **Treatment Depth**: Installed in whole feet between 8 ft and 25 ft below footing soffit (CR-P1, P2, P6: 11 ft; CR-P4: 9 ft).
* **Top-of-Pier Stress Limit**: <= 18,000 psf verified at 150% design load (Kettleridge Section 2).
* **Pier Spacing / Replacement Ratio**: Minimum clear spacing of 1.0 ft (c-c spacing >= 3.5 ft); area replacement ratio Ra <= 0.40.
* **Verification Testing**: One production modulus test per improved pad ($9,500 each, Kettleridge Section 5).

---

## 5. Conflict Resolution and Governing Values
1. **Air Freezing Index Edition**: NCEI 1951-1980 tables (416 F-days) vs. 1981-2010 normals (556 F-days). Resolved per AHJ Amendment 3 and RFI-007: 1981-2010 normals govern (556 F-days > 500 F-days), dictating minimum bearing depth of 42 inches (3.5 ft).
2. **Presumptive Bearing Capacity**: GDR Rev 2 preliminary 3,000 psf vs. UFC 3-220-01 / AHJ Amendment 4 prohibition. Resolved: Presumptive values prohibited; site-specific analysis governs throughout.
3. **Footing Spacing Guideline (1.5B)**: UFC 3-220-01 2-4.8.1 preliminary guideline. Resolved per RFI-017: Size, schedule, and price foundations as individual units with no reduction factor.
4. **Concrete Durability Conflict**: UFGS 03 30 00 exposure classes vs. Basis of Design. Resolved: Pad-specific most restrictive limits govern (CR-P1/P4: S1/W1 -> 4000 psi, w/cm <= 0.50; CR-P2/P6: S2 -> 4500 psi, w/cm <= 0.45; CR-P3: W1 -> 4000 psi, w/cm <= 0.50; CR-P5: F3 -> 5000 psi, w/cm <= 0.40).

---

## 6. Campus Foundation Strategy and Mobilisation Programme
* **Mobilisation Terms**: Each mobilised rig serves at most 2 pads within the milestone window at $40,000 lump sum per rig (Kettleridge Section 4).
* **Pads CR-P1, CR-P2, CR-P6**: Bearing in soft Stratum I residual soils (Es = 85 to 110 ksf). Unimproved spread footings at frost elevation (42 in) are physically infeasible (settlement > 1.0 in, angular distortion > 1/500). Deepening to Stratum II requires costly dewatering ($63k) and massive excavations. Ground improvement over aggregate piers is compliant and substantially cheaper. These three pads require 2 rigs.
* **Pad CR-P4**: Spread footings are technically feasible but require huge footings costing $61,623. Because 2 rigs are already mobilised for CR-P1, CR-P2, and CR-P6 (serving up to 4 pads), Rig 2 has surplus capacity to serve CR-P4 at zero extra mobilisation cost. Ground improvement on CR-P4 costs $48,943, saving $12,680. Thus, CR-P4 is improved.
* **Pads CR-P3 and CR-P5**: Founded over stiff, thin Stratum I soils (Es = 210 to 250 ksf). Spread footings alone at 42 in bearing depth are fully compliant and highly economical ($30,597 for CR-P3, $11,805 for CR-P5). Improving either pad would trigger a 3rd rig ($40,000) and production modulus testing ($9,500), adding over $50k in unnecessary costs.
* **Campus Programme**: Exactly **2 rigs** mobilised, serving **4 improved pads** (`CR-P1`, `CR-P2`, `CR-P4`, `CR-P6`), with **2 unimproved pads** (`CR-P3`, `CR-P5`), achieving the globally minimum compliant cost of **$423,252.57**.
