```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 181943.94,
      "improved_cost_usd": 79086.84
    },
    "CR-P2": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 277599.89,
      "improved_cost_usd": 87659.12
    },
    "CR-P3": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 31196.88,
      "improved_cost_usd": 53836.93
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 58917.05,
      "improved_cost_usd": 44555.46
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 16555.9,
      "improved_cost_usd": 34697.61
    },
    "CR-P6": {
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 192154.55,
      "improved_cost_usd": 84435.18
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 423489.38,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC 3-220-10N Soil Mechanics 2005 (Cancelled predecessor volume)",
    "UFC 3-220-01N Foundation Design 2005 (Cancelled predecessor volume)",
    "FHWA GEC 6 Shallow Foundations (Written for highway bridge structures)",
    "AV-CR-2604 Basis of Design Structural Rev 1 (Superseded by Rev 3)",
    "AV-CR-2604 Geotechnical Addendum 1 (Superseded by Geotechnical Data Report Rev 2)",
    "NOAA NCEI 1951-1980 AFI return periods (Superseded by 1981-2010 normals per AHJ letter LC-BD-26-0774 Amendment 3)",
    "Broadview Commons adjacent parcel subsurface report (Off-site parcel, information only)",
    "USACE EM 1110-2-2104 Table 3-1 load factors (Hydraulic structures only, set aside per load combination memo)"
  ]
}
```

# Basis of Design Narrative — Cattail Run Data Campus Phase 1
**Ardent Vale Infrastructure LLC | Loudoun County, Virginia**
**Structural Engineer of Record Foundation Package Report**

## 1. Governing Criteria and Rejected Documents

### 1.1 Governing Documents
This engineering foundation package is prepared in strict compliance with the following active criteria and standards:
1. **UFC 3-220-01 (Change 3, July 2025)**, *Geotechnical Engineering*: Governing military standard for geotechnical investigations, factors of safety, shallow foundation design, tolerable movements, and minimum dimensions.
2. **UFC 3-301-01 (Change 4, June 2025)**, *Structural Engineering*: Governing standard for structural load combinations, concrete footing design, and reinforcement detailing.
3. **UFGS 03 30 00**, *Cast-in-Place Concrete*: Durability requirements for concrete compressive strength f'c and water-cementitious materials ratio (w/cm) across environmental exposure classes.
4. **UFGS 31 00 00**, *Earthwork*: Requirements for excavation, fill placement, compaction, and grading tolerances.
5. **USACE EM 1110-1-1905**, *Bearing Capacity of Soils*: Solution methods for ultimate and net allowable bearing capacity, shape factors, depth factors, and groundwater corrections.
6. **UFC 3-220-20 (DM 7.2, 2025)**, *Foundations and Earth Structures*: Bearing capacity and settlement formulation for spread foundations.
7. **USACE EM 1110-2-2502**, *Retaining and Flood Walls*: Limit-equilibrium stability checks against sliding, overturning, and uplift.
8. **FHWA GEC 13 (NHI-16-027)**, *Ground Modification Methods Reference Manual*: Two-layer settlement analysis and stress concentration modeling for rammed aggregate piers.
9. **Loudoun County AHJ Amendment Letter LC-BD-26-0774 (2026-08-14)**: Amendments 3 and 4 establishing municipal frost protection requirements and prohibiting presumptive bearing pressures.
10. **AV-CR-2604 Basis of Design Structural Rev 3**: Owner design basis establishing occupancy classifications, exposure classes, dimensioning rules, and material unit prices.

### 1.2 Rejected and Superseded Predecessor Documents
The following documents were reviewed and explicitly set aside:
- **UFC 3-220-10N (2005)** and **UFC 3-220-01N (2005)**: Cancelled predecessor NAVFAC DM-7.1 and DM-7.2 editions, superseded by UFC 3-220-01 and UFC 3-220-20.
- **FHWA GEC 6**: Shallow foundations reference manual written specifically for highway bridges and bridge abutments, not for building foundations.
- **AV-CR-2604 Basis of Design Structural Rev 1**: Superseded in its entirety by Revision 3 (which eliminated uniform F0/Warehouse classifications and 1-inch dimensioning).
- **AV-CR-2604 Geotechnical Addendum 1**: Superseded by Geotechnical Data Report Rev 2 (withdrew uniform modulus estimates and 4,000 psf presumptive bearing capacity).
- **NOAA NCEI Air-Freezing Index 1951-1980 Tables**: Superseded edition. AHJ Amendment 3 explicitly dictates that the current 1981-2010 normals product governs.
- **Broadview Commons Adjacent Parcel Report (2023)**: Off-site subsurface report for an adjacent parcel with distinct geology; retained for information only per RFI-013.
- **USACE EM 1110-2-2104 Table 3-1 Load Factors**: Intended strictly for hydraulic structures (dams, locks, flood walls); set aside per Load Combination Memo Section 3 in favor of standard building load factors.

---

## 2. Bearing Capacity, Settlement, and Tolerable Movement Methods

### 2.1 Bearing Capacity Analysis and Factor of Safety
Per UFC 3-220-01 paragraph 2-4.7.1, ultimate bearing capacity was evaluated using three widely accepted analytical methods:
1. **Meyerhof (1963)** general bearing capacity equation.
2. **Brinch Hansen (1970)** formulation with shape and depth factors.
3. **Vesic (1973, 1975)** formulation with embedment factors.

The governing net allowable bearing pressure reported for each foundation represents the least (most conservative) of the three methods, controlled by the Hansen formulation:
$$q_{all,net} = \frac{q_u - \sigma_D}{FS}$$

The factor of safety (FS) applied on each pad is established strictly from UFC 3-220-01 Table 2-3 based on building occupancy:
- **CR-P1, CR-P2, CR-P3, CR-P6** (Data Halls 1-3, Electrical Yard Building): Classified as *Light Industrial, Public* -> **FS = 3.5**.
- **CR-P4** (Administration and Operations Building): Classified as *Apartments, Office* -> **FS = 3.0**.
- **CR-P5** (Logistics and Spares Warehouse): Classified as *Warehouse* -> **FS = 2.5**.

Groundwater corrections to effective unit weight within the failure zone ($H = B \tan(45^\circ + \phi/2)$) were incorporated using EM 1110-1-1905 Equation 1-6. Because all footings are founded at the frost minimum depth of 42 inches (3.5 ft), which is well above the stabilised piezometric groundwater levels (8.0 to 21.0 ft), the footing bases bear dry without requiring construction dewatering.

### 2.2 Settlement Analysis Method
In accordance with RFI-019 and FHWA GEC 13 Equation 5-14, settlement was computed using **Layered Elastic Compression**:
- The soil column below the footing soffit is subdivided into uniform layers 0.25 ft (3 inches) thick.
- Net vertical stress increments $\Delta\sigma(z_m)$ at layer mid-heights are computed using the 2:1 (vertical to horizontal) pyramidal distribution:
  $$\Delta\sigma(z_m) = \frac{P_{service}}{(B + z_m)(L + z_m)}$$
- Layer compressions $s_i = \Delta\sigma(z_m) \cdot \Delta z / E_s(z_m)$ are summed to a depth of four times the footing width ($4B$), but in no case less than 40.0 ft.
- Pad-specific secant elastic moduli from Geotechnical Data Report Rev 2 are mapped to each layer based on linearly interpolated stratum boundaries.

### 2.3 Tolerable Movement Criteria
Tolerable movements are governed by UFC 3-220-01 paragraph 2-4.7.1:
- **Maximum Total Post-Construction Settlement**: $s_{total} \le 1.0\text{ in}$ (25.4 mm). Competing relaxed limits (e.g. 2.0 inches in general references) were rejected.
- **Maximum Angular Distortion**: $\theta = |\Delta s| / L_{span} \le 1/500$ (0.0020 rad) between any adjacent foundation units along the column line.

---

## 3. Ground Improvement Strategy and Parameter Derivations

### 3.1 Rammed Aggregate Pier Design Parameters
For pads where shallow spread footings alone cannot limit settlement to 1.0 inch within column bay geometries, rammed aggregate piers are deployed:
- **Pier Diameter**: 30 inches (2.5 ft), per Kettleridge Ground Systems proposal KGS-26-0917.
- **Stress Concentration Ratio ($n_s$)**: 10.0, per FHWA GEC 13 Section 4.2.1 (p. 358) for structure foundation support under rigid footings. Proprietary vendor claims of $n_s \ge 20$ were rejected per RFI-011.
- **Area Replacement Ratio ($R_a$)**: Maintained between 0.33 (minimum recommended by FHWA GEC 13 / HITEC Collin 2007) and 0.46 (maximum geometric packing at 1.0 ft clear spacing on staggered grid).
- **Maximum Top-of-Pier Stress ($q_g$)**: 18,000 psf (18.0 ksf), the warranty threshold certified by pre-production modulus testing.
- **Pier Stiffness Modulus ($k_g$)**: Pad-specific design values from June 2026 pre-production modulus tests (P1: 165, P2: 140, P4: 195, P6: 155 pci).
- **Two-Layer Settlement Formulation**:
  - Upper zone settlement: $s_{uz} = (q_g / 144) / k_g$ (inches).
  - Lower zone settlement: Layered elastic compression integrated from pier tip ($z = H_{pier}$) down to $\max(4B, 40\text{ ft})$.

---

## 4. Resolution of Document Conflicts

1. **Frost Penetration Depth**:
   - *Conflict*: Superceded 1951-1980 NOAA NCEI tables listed a 100-year AFI of 416 F-days (which would require 30 in frost depth under AHJ letter).
   - *Resolution*: AHJ Letter LC-BD-26-0774 Amendment 3 explicitly mandates the current 1981-2010 normals product. NOAA cooperative station USC00444909 (Lincoln, VA) records a 100-year AFI of 556 F-days (> 500 F-days). The governing foundation depth is therefore **42 inches** below finished grade across all pads.
2. **Presumptive Bearing Values**:
   - *Conflict*: Geotechnical report Rev 2 mentioned a preliminary presumptive bearing capacity of 3,000 psf for Stratum I.
   - *Resolution*: Presumptive values are strictly prohibited by AHJ Amendment 4 and UFC 3-220-01 paragraph 2-4.5.2 for sites where subsurface investigations have been conducted. Footings are sized based on rigorous site-specific limit-state calculations.
3. **Footing Proximity (1.5B Spacing Rule)**:
   - *Conflict*: UFC 3-220-01 paragraph 2-4.8.1 suggests foundation spacing of at least 1.5 times the larger width.
   - *Resolution*: Clarified by RFI-017 as a preliminary guideline. Foundations are sized, scheduled, and priced as discrete units without arbitrary capacity penalties.
4. **Concrete Durability vs Structural Strength**:
   - *Conflict*: Structural demand can be met with 3,000 psi concrete, but environmental durability classes dictate higher minimum strengths.
   - *Resolution*: UFGS 03 30 00 and Basis of Design Rev 3 govern: the lowest available plant mix satisfying both structural and durability criteria was assigned (4,000 psi for P1, P3, P4; 4,500 psi for P2, P6; 5,000 psi for P5).

---

## 5. Campus Programme Optimisation and Rig Mobilisation

### 5.1 Pad-by-Pad Optimization Summary
1. **CR-P1 (Data Hall 1)**: Stratum I modulus is soft ($E_s = 110$ ksf) under high column loads ($P_{service}$ up to 1,420 kips). Spread footings alone would experience settlements up to 3.38 inches; settlement-compliant spread footings would require widths exceeding 30 ft (costing $181,943.94 and physically overlapping). Improved spread footings limit settlement to 0.77 in at a cost of **$79,086.84**. **IMPROVED SPREAD GOVERNS (BEARING selects final plan dimensions at 99.2% of allowable).**
2. **CR-P2 (Data Hall 2)**: Softest foundation soils on campus ($E_s = 85$ ksf) under heavy loads. Unimproved settlement exceeds 4.2 inches. Spread footings would cost $277,599.89. Improved spread footings provide compliant performance at **$87,659.12**. **IMPROVED SPREAD GOVERNS (SETTLEMENT selects final plan dimensions at 99.7% of allowable).**
3. **CR-P3 (Electrical Yard Building)**: Stiff soils ($E_s = 210$ ksf) and moderate column loads. Spread footings sized to B=99-168 in achieve settlements of 0.70 to 0.995 in and maximum angular distortion of 1/848 (well within 1/500). Total spread cost is **$31,196.88**, compared to $53,836.93 for ground improvement. **SPREAD FOOTING GOVERNS (SETTLEMENT selects final plan dimensions at 99.5% of allowable).**
4. **CR-P4 (Administration and Operations Building)**: Moderate soil stiffness ($E_s = 130$ ksf). Sized as spread footings, total cost is $58,917.05 to satisfy settlement. With aggregate piers, footing sizes are substantially reduced, costing **$44,555.46** (saving $14,361.59). Because Rig 2 is already mobilised for CR-P6, CR-P4 absorbs zero additional rig mobilisation cost. **IMPROVED SPREAD GOVERNS (BEARING selects final plan dimensions at 99.7% of allowable).**
5. **CR-P5 (Logistics and Spares Warehouse)**: Stiffest soil on campus ($E_s = 250$ ksf) and lowest bearing safety factor ($FS = 2.5$). Footings are strictly bearing-controlled; predicted settlements are only 0.53 to 0.80 inches. Spread footings cost **$16,555.90**, compared to $34,697.61 for ground improvement. **SPREAD FOOTING GOVERNS (BEARING selects final plan dimensions at 99.7% of allowable).**
6. **CR-P6 (Data Hall 3)**: Soft matrix soils ($E_s = 95$ ksf) with heavy reactions. Spread-only footings cost $192,154.55. Improved footings cost **$84,435.18**, saving over $107,700. **IMPROVED SPREAD GOVERNS (SETTLEMENT selects final plan dimensions at 92.5% of allowable).**

### 5.2 Rig Mobilisation Strategy
- Subcontractor terms restrict each mobilised rig to serving **at most 2 building pads** within the milestone window.
- Exactly **4 pads** are improved: `CR-P1`, `CR-P2`, `CR-P4`, and `CR-P6`.
- Exactly **2 rigs** are mobilised:
  - **RIG-1**: Dedicated to `CR-P1` and `CR-P2` (2 pads).
  - **RIG-2**: Dedicated to `CR-P4` and `CR-P6` (2 pads).
- Mobilisation cost: $2 \times \$40,000 = **\$80,000.00**.
- Every rig operates at 100% capacity with zero wasted mobilisations.
- **Total Campus Foundation Package Cost**: **$423,489.38**.
