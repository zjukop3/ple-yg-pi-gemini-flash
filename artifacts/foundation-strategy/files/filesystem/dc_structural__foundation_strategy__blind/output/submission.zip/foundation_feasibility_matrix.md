# Foundation Feasibility and Optimisation Matrix
**Cattail Run Data Campus — Phase 1 Foundation Strategy**
**Ardent Vale Infrastructure LLC | Loudoun County, Virginia**

This document presents the foundation-type feasibility, design calculations, stability checks, and cost optimisation for each building pad (CR-P1 through CR-P6).

---

## Pad CR-P1 — Data Hall 1
- **Occupancy Classification**: Light Industrial, Public (UFC 3-220-01 Table 2-3 Factor of Safety FS = 3.5)
- **Stratum I Drained Modulus Es**: 110.0 ksf
- **Sulfate Exposure**: 0.14% SO4 -> Class S1 (f'c = 4000 psi, max w/cm = 0.5)
- **Governing Pad Constraint**: `BEARING`
- **Foundation Strategy Decision**: `IMPROVED_SPREAD`
  - **Spread-Only Alternative Cost**: $181,943.94
  - **Improved Spread Alternative Cost**: $79,086.84
  - **Economic and Technical Resolution**: Improved spread footing using rammed aggregate piers reduces total settlement from > 3.0 in to < 1.0 in, eliminates foundation overlapping along column line A, and provides a cost-optimal solution.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | IMPROVED_SPREAD | 129" x 129" x 27" | 5.28 | 5.28 | OK (q_net <= q_all) | 0.666 | OK (s <= 1.0") | 8 ea x 8 ft | 13,007 | `BEARING` |
| F2 | IMPROVED_SPREAD | 180" x 180" x 39" | 5.24 | 5.30 | OK (q_net <= q_all) | 0.728 | OK (s <= 1.0") | 16 ea x 8 ft | 12,663 | `BEARING` |
| F3 | IMPROVED_SPREAD | 198" x 198" x 42" | 5.22 | 5.32 | OK (q_net <= q_all) | 0.766 | OK (s <= 1.0") | 19 ea x 8 ft | 12,774 | `BEARING` |
| F4 | IMPROVED_SPREAD | 165" x 165" x 33" | 5.18 | 5.28 | OK (q_net <= q_all) | 0.725 | OK (s <= 1.0") | 13 ea x 8 ft | 12,838 | `BEARING` |
| F5 | IMPROVED_SPREAD | 120" x 120" x 24" | 5.20 | 5.29 | OK (q_net <= q_all) | 0.736 | OK (s <= 1.0") | 7 ea x 8 ft | 12,706 | `BEARING` |
| W1 | IMPROVED_SPREAD | 171" x 288" x 30" | 4.82 | 4.86 | OK (q_net <= q_all) | 0.731 | OK (s <= 1.0") | 23 ea x 9 ft | 12,149 | `SETTLEMENT` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 278.4 kips vs Driving shear Hx = 96.0 kips -> **FS_sliding = 2.90** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 807.5 kips vs Uplift demand = 260.0 kips -> **FS_uplift = 3.11** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---

## Pad CR-P2 — Data Hall 2
- **Occupancy Classification**: Light Industrial, Public (UFC 3-220-01 Table 2-3 Factor of Safety FS = 3.5)
- **Stratum I Drained Modulus Es**: 85.0 ksf
- **Sulfate Exposure**: 0.23% SO4 -> Class S2 (f'c = 4500 psi, max w/cm = 0.45)
- **Governing Pad Constraint**: `SETTLEMENT`
- **Foundation Strategy Decision**: `IMPROVED_SPREAD`
  - **Spread-Only Alternative Cost**: $277,599.89
  - **Improved Spread Alternative Cost**: $87,659.12
  - **Economic and Technical Resolution**: Improved spread footing using rammed aggregate piers reduces total settlement from > 3.0 in to < 1.0 in, eliminates foundation overlapping along column line A, and provides a cost-optimal solution.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | IMPROVED_SPREAD | 135" x 135" x 27" | 5.11 | 5.30 | OK (q_net <= q_all) | 0.946 | OK (s <= 1.0") | 9 ea x 9 ft | 12,336 | `BEARING` |
| F2 | IMPROVED_SPREAD | 186" x 186" x 39" | 5.21 | 5.33 | OK (q_net <= q_all) | 0.997 | OK (s <= 1.0") | 17 ea x 8 ft | 12,618 | `SETTLEMENT` |
| F3 | IMPROVED_SPREAD | 204" x 204" x 42" | 5.21 | 5.35 | OK (q_net <= q_all) | 0.882 | OK (s <= 1.0") | 20 ea x 8 ft | 12,837 | `BEARING` |
| F4 | IMPROVED_SPREAD | 168" x 168" x 33" | 5.30 | 5.31 | OK (q_net <= q_all) | 0.824 | OK (s <= 1.0") | 14 ea x 8 ft | 12,754 | `BEARING` |
| F5 | IMPROVED_SPREAD | 123" x 123" x 24" | 5.25 | 5.31 | OK (q_net <= q_all) | 0.718 | OK (s <= 1.0") | 8 ea x 8 ft | 12,022 | `BEARING` |
| W1 | IMPROVED_SPREAD | 180" x 288" x 33" | 4.86 | 4.94 | OK (q_net <= q_all) | 0.787 | OK (s <= 1.0") | 25 ea x 10 ft | 11,943 | `SETTLEMENT` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 297.4 kips vs Driving shear Hx = 101.8 kips -> **FS_sliding = 2.92** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 857.4 kips vs Uplift demand = 275.6 kips -> **FS_uplift = 3.11** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---

## Pad CR-P3 — Electrical Yard Building
- **Occupancy Classification**: Light Industrial, Public (UFC 3-220-01 Table 2-3 Factor of Safety FS = 3.5)
- **Stratum I Drained Modulus Es**: 210.0 ksf
- **Sulfate Exposure**: 0.07% SO4 -> Class S0 (f'c = 4000 psi, max w/cm = 0.5)
- **Governing Pad Constraint**: `SETTLEMENT`
- **Foundation Strategy Decision**: `SPREAD`
  - **Spread-Only Alternative Cost**: $31,196.88
  - **Improved Spread Alternative Cost**: $53,836.93
  - **Economic and Technical Resolution**: Shallow spread footings alone satisfy all bearing capacity, total settlement (<= 1.0 in), and angular distortion (<= 1/500) criteria without ground improvement, saving specialty mobilisation, modulus testing, and aggregate pier installation costs.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | SPREAD | 108" x 108" x 21" | 5.42 | 5.57 | OK (q_net <= q_all) | 0.698 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F2 | SPREAD | 150" x 150" x 33" | 5.44 | 5.57 | OK (q_net <= q_all) | 0.898 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F3 | SPREAD | 168" x 168" x 33" | 5.22 | 5.58 | OK (q_net <= q_all) | 0.995 | OK (s <= 1.0") | None | N/A | `SETTLEMENT` |
| F4 | SPREAD | 138" x 138" x 27" | 5.34 | 5.57 | OK (q_net <= q_all) | 0.983 | OK (s <= 1.0") | None | N/A | `SETTLEMENT` |
| F5 | SPREAD | 99" x 99" x 21" | 5.50 | 5.57 | OK (q_net <= q_all) | 0.921 | OK (s <= 1.0") | None | N/A | `BEARING` |
| W1 | SPREAD | 126" x 288" x 24" | 4.71 | 5.01 | OK (q_net <= q_all) | 0.991 | OK (s <= 1.0") | None | N/A | `SETTLEMENT` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 197.2 kips vs Driving shear Hx = 69.1 kips -> **FS_sliding = 2.85** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 579.3 kips vs Uplift demand = 187.2 kips -> **FS_uplift = 3.09** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---

## Pad CR-P4 — Administration and Operations Building
- **Occupancy Classification**: Apartments, Office (UFC 3-220-01 Table 2-3 Factor of Safety FS = 3.0)
- **Stratum I Drained Modulus Es**: 130.0 ksf
- **Sulfate Exposure**: 0.11% SO4 -> Class S1 (f'c = 4000 psi, max w/cm = 0.5)
- **Governing Pad Constraint**: `BEARING`
- **Foundation Strategy Decision**: `IMPROVED_SPREAD`
  - **Spread-Only Alternative Cost**: $58,917.05
  - **Improved Spread Alternative Cost**: $44,555.46
  - **Economic and Technical Resolution**: Improved spread footing using rammed aggregate piers reduces total settlement from > 3.0 in to < 1.0 in, eliminates foundation overlapping along column line A, and provides a cost-optimal solution.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | IMPROVED_SPREAD | 96" x 96" x 21" | 6.00 | 6.24 | OK (q_net <= q_all) | 0.571 | OK (s <= 1.0") | 5 ea x 8 ft | 13,489 | `BEARING` |
| F2 | IMPROVED_SPREAD | 132" x 132" x 30" | 6.14 | 6.16 | OK (q_net <= q_all) | 0.654 | OK (s <= 1.0") | 9 ea x 8 ft | 14,335 | `BEARING` |
| F3 | IMPROVED_SPREAD | 147" x 147" x 30" | 5.96 | 6.15 | OK (q_net <= q_all) | 0.666 | OK (s <= 1.0") | 11 ea x 8 ft | 14,065 | `BEARING` |
| F4 | IMPROVED_SPREAD | 123" x 123" x 27" | 5.88 | 6.17 | OK (q_net <= q_all) | 0.609 | OK (s <= 1.0") | 8 ea x 8 ft | 13,466 | `BEARING` |
| F5 | IMPROVED_SPREAD | 87" x 87" x 18" | 6.23 | 6.29 | OK (q_net <= q_all) | 0.598 | OK (s <= 1.0") | 4 ea x 8 ft | 14,288 | `BEARING` |
| W1 | IMPROVED_SPREAD | 102" x 288" x 21" | 5.10 | 5.25 | OK (q_net <= q_all) | 0.603 | OK (s <= 1.0") | 14 ea x 8 ft | 12,638 | `BEARING` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 168.0 kips vs Driving shear Hx = 60.5 kips -> **FS_sliding = 2.78** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 500.5 kips vs Uplift demand = 163.8 kips -> **FS_uplift = 3.06** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---

## Pad CR-P5 — Logistics and Spares Warehouse
- **Occupancy Classification**: Warehouse (UFC 3-220-01 Table 2-3 Factor of Safety FS = 2.5)
- **Stratum I Drained Modulus Es**: 250.0 ksf
- **Sulfate Exposure**: 0.05% SO4 -> Class S0 (f'c = 5000 psi, max w/cm = 0.4)
- **Governing Pad Constraint**: `BEARING`
- **Foundation Strategy Decision**: `SPREAD`
  - **Spread-Only Alternative Cost**: $16,555.90
  - **Improved Spread Alternative Cost**: $34,697.61
  - **Economic and Technical Resolution**: Shallow spread footings alone satisfy all bearing capacity, total settlement (<= 1.0 in), and angular distortion (<= 1/500) criteria without ground improvement, saving specialty mobilisation, modulus testing, and aggregate pier installation costs.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | SPREAD | 81" x 81" x 18" | 7.36 | 7.83 | OK (q_net <= q_all) | 0.528 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F2 | SPREAD | 111" x 111" x 24" | 7.59 | 7.81 | OK (q_net <= q_all) | 0.691 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F3 | SPREAD | 120" x 120" x 27" | 7.81 | 7.83 | OK (q_net <= q_all) | 0.799 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F4 | SPREAD | 102" x 102" x 21" | 7.46 | 7.80 | OK (q_net <= q_all) | 0.768 | OK (s <= 1.0") | None | N/A | `BEARING` |
| F5 | SPREAD | 75" x 75" x 18" | 7.32 | 7.87 | OK (q_net <= q_all) | 0.706 | OK (s <= 1.0") | None | N/A | `BEARING` |
| W1 | SPREAD | 72" x 288" x 15" | 6.30 | 6.48 | OK (q_net <= q_all) | 0.753 | OK (s <= 1.0") | None | N/A | `BEARING` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 138.8 kips vs Driving shear Hx = 52.8 kips -> **FS_sliding = 2.63** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 424.7 kips vs Uplift demand = 143.0 kips -> **FS_uplift = 2.97** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---

## Pad CR-P6 — Data Hall 3
- **Occupancy Classification**: Light Industrial, Public (UFC 3-220-01 Table 2-3 Factor of Safety FS = 3.5)
- **Stratum I Drained Modulus Es**: 95.0 ksf
- **Sulfate Exposure**: 0.26% SO4 -> Class S2 (f'c = 4500 psi, max w/cm = 0.45)
- **Governing Pad Constraint**: `SETTLEMENT`
- **Foundation Strategy Decision**: `IMPROVED_SPREAD`
  - **Spread-Only Alternative Cost**: $192,154.55
  - **Improved Spread Alternative Cost**: $84,435.18
  - **Economic and Technical Resolution**: Improved spread footing using rammed aggregate piers reduces total settlement from > 3.0 in to < 1.0 in, eliminates foundation overlapping along column line A, and provides a cost-optimal solution.

### Foundation Demands and Analysis Summary

| Foundation | Type | Dimensions B x L x t (in) | Applied q_net (ksf) | Allowable q_all (ksf) | Bearing Check | Predicted Settlement (in) | Settlement Check (<= 1.0 in) | Piers (count x H ft) | Top-of-Pier Stress (psf) | Governing Constraint |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| F1 | IMPROVED_SPREAD | 132" x 132" x 27" | 5.14 | 5.29 | OK (q_net <= q_all) | 0.925 | OK (s <= 1.0") | 9 ea x 9 ft | 11,998 | `BEARING` |
| F2 | IMPROVED_SPREAD | 183" x 183" x 36" | 5.18 | 5.31 | OK (q_net <= q_all) | 0.854 | OK (s <= 1.0") | 16 ea x 8 ft | 12,812 | `BEARING` |
| F3 | IMPROVED_SPREAD | 198" x 198" x 42" | 5.32 | 5.33 | OK (q_net <= q_all) | 0.818 | OK (s <= 1.0") | 19 ea x 8 ft | 13,029 | `BEARING` |
| F4 | IMPROVED_SPREAD | 165" x 165" x 33" | 5.29 | 5.29 | OK (q_net <= q_all) | 0.764 | OK (s <= 1.0") | 13 ea x 8 ft | 13,094 | `BEARING` |
| F5 | IMPROVED_SPREAD | 123" x 123" x 24" | 5.05 | 5.30 | OK (q_net <= q_all) | 0.628 | OK (s <= 1.0") | 8 ea x 8 ft | 11,568 | `BEARING` |
| W1 | IMPROVED_SPREAD | 174" x 288" x 30" | 4.84 | 4.89 | OK (q_net <= q_all) | 0.693 | OK (s <= 1.0") | 24 ea x 11 ft | 11,951 | `SETTLEMENT` |

### Shear-Wall Footing (W1) Stability Checks
- **Sliding Stability (0.6D + W)**: Resisting shear = 283.8 kips vs Driving shear Hx = 97.9 kips -> **FS_sliding = 2.90** (Limit: FS >= 1.5 per EM 1110-2-2502 / FS >= 2.0 per UFC 3-220-01) -> **PASS**
- **Overturning Stability (D + L + W)**: Resultant eccentricity **e = 6.40 in** (0.53 ft) vs Middle Third Kern L/6 = 48.0 in (4.00 ft) -> **PASS (Resultant within middle third)**
- **Net Uplift Stability (0.6D + W)**: Resisting gravity = 823.4 kips vs Uplift demand = 265.2 kips -> **FS_uplift = 3.10** (Limit: FS >= 1.0 ASD / FS >= 1.5) -> **PASS**

---
