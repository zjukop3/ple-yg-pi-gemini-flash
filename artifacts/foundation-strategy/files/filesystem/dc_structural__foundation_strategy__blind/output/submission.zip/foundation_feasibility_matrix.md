# Foundation Feasibility and Optimisation Matrix
Cattail Run Data Campus — Phase 1 Foundation Package (AV-CR-2604)

## Executive Summary
This feasibility and optimisation matrix documents the foundation design decisions for all 36 foundation units across building pads `CR-P1` through `CR-P6`. Sizing and ground improvement determinations are evaluated against the governing geotechnical criteria (UFC 3-220-01 Change 3, UFC 3-220-20), structural concrete criteria (UFGS 03 30 00, UFC 3-301-01), AHJ permit requirements (Loudoun County AHJ letter LC-BD-26-0774), and the project budget prices.

### Campus Summary and Rig Mobilisation
* **Rigs Mobilised**: 2 rigs
* **Mobilisation Cost**: $80,000 ($40,000 per rig, maximum 2 pads per rig)
* **Pads Improved**: `CR-P1`, `CR-P2`, `CR-P4`, `CR-P6` (served by RIG-1: CR-P1 & CR-P2; RIG-2: CR-P4 & CR-P6)
* **Pads Unimproved (Spread Footings Alone)**: `CR-P3`, `CR-P5`
* **Total Campus Foundation Cost**: $423,252.57

---

## CR-P1

* **Building**: Light Industrial, Public
* **Occupancy Class / Factor of Safety**: Light Industrial, Public (FS = 3.5)
* **Concrete Specification**: f'c = 4000 psi, max w/cm = 0.50 (Exposure classes: F1, W1, C1, S1)
* **Foundation Decision**: `IMPROVED_SPREAD`
* **Governing Pad Constraint**: `SETTLEMENT`
* **Cost Comparison**: Spread-Only Alternative = $142,500.00 | Improved Alternative = $77,916.48
* **Decision Rationale**: Stratum I residual soils are soft (Es = 110.0 ksf). Unimproved spread footings at the 42-in frost elevation exceed the 1.0-in total settlement limit and 1/500 angular distortion limit even at excessive dimensions (>25 ft). Deepening footings into Stratum II would require deep excavation and costly dewatering below the groundwater table (depth 8.0 ft), costing $142,500. Sizing footings over rammed aggregate piers (depth 11 ft, diameter 30 in) limits total settlement to <= 0.98 in and angular distortion to < 1/500 at a cost of $77,916, saving $64,584.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | IMPROVED_SPREAD | 132 x 132 | 27 | 610.0 | 5.04 | 5.45 | 0.833 | 5 x 11 ft | 17842 | - | BEARING |
| F2 | IMPROVED_SPREAD | 177 x 177 | 39 | 1180.0 | 5.42 | 5.46 | 0.814 | 12 x 11 ft | 15782 | - | BEARING |
| F3 | IMPROVED_SPREAD | 195 x 195 | 42 | 1420.0 | 5.38 | 5.48 | 0.932 | 12 x 11 ft | 17880 | - | BEARING |
| F4 | IMPROVED_SPREAD | 162 x 162 | 33 | 980.0 | 5.38 | 5.45 | 0.854 | 9 x 11 ft | 16901 | - | BEARING |
| F5 | IMPROVED_SPREAD | 120 x 120 | 24 | 520.0 | 5.20 | 5.46 | 0.771 | 5 x 11 ft | 16205 | - | BEARING |
| W1 | IMPROVED_SPREAD | 168 x 288 | 30 | 1650.0 | 4.91 | 4.94 | 0.854 | 16 x 11 ft | 15822 | Sliding FS=2.83, e=7.4in, Uplift FS=3.10 | BEARING |

---

## CR-P2

* **Building**: Light Industrial, Public
* **Occupancy Class / Factor of Safety**: Light Industrial, Public (FS = 3.5)
* **Concrete Specification**: f'c = 4500 psi, max w/cm = 0.45 (Exposure classes: F1, W1, C1, S2)
* **Foundation Decision**: `IMPROVED_SPREAD`
* **Governing Pad Constraint**: `SETTLEMENT`
* **Cost Comparison**: Spread-Only Alternative = $158,000.00 | Improved Alternative = $88,012.27
* **Decision Rationale**: Stratum I residual soils are soft (Es = 85.0 ksf). Unimproved spread footings at the 42-in frost elevation exceed the 1.0-in total settlement limit and 1/500 angular distortion limit even at excessive dimensions (>25 ft). Deepening footings into Stratum II would require deep excavation and costly dewatering below the groundwater table (depth 9.0 ft), costing $158,000. Sizing footings over rammed aggregate piers (depth 11 ft, diameter 30 in) limits total settlement to <= 0.98 in and angular distortion to < 1/500 at a cost of $88,012, saving $69,988.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | IMPROVED_SPREAD | 147 x 147 | 27 | 646.6 | 4.31 | 5.47 | 0.971 | 5 x 11 ft | 17431 | - | SETTLEMENT |
| F2 | IMPROVED_SPREAD | 186 x 186 | 39 | 1250.8 | 5.21 | 5.50 | 0.978 | 12 x 11 ft | 16236 | - | SETTLEMENT |
| F3 | IMPROVED_SPREAD | 201 x 201 | 42 | 1505.2 | 5.37 | 5.52 | 0.948 | 16 x 11 ft | 15244 | - | SETTLEMENT |
| F4 | IMPROVED_SPREAD | 168 x 168 | 33 | 1038.8 | 5.30 | 5.48 | 0.852 | 12 x 11 ft | 14306 | - | BEARING |
| F5 | IMPROVED_SPREAD | 123 x 123 | 24 | 551.2 | 5.25 | 5.49 | 0.924 | 5 x 11 ft | 16910 | - | BEARING |
| W1 | IMPROVED_SPREAD | 177 x 288 | 33 | 1749.0 | 4.94 | 5.03 | 0.933 | 18 x 11 ft | 15219 | Sliding FS=2.83, e=7.6in, Uplift FS=3.10 | BEARING |

---

## CR-P3

* **Building**: Light Industrial, Public
* **Occupancy Class / Factor of Safety**: Light Industrial, Public (FS = 3.5)
* **Concrete Specification**: f'c = 4000 psi, max w/cm = 0.50 (Exposure classes: F1, W1, C1, S0)
* **Foundation Decision**: `SPREAD`
* **Governing Pad Constraint**: `SETTLEMENT`
* **Cost Comparison**: Spread-Only Alternative = $32,729.45 | Improved Alternative = $49,500.00
* **Decision Rationale**: Stratum I is relatively stiff (Es = 210 ksf) and thin (5.5 to 7.0 ft deep). Unimproved spread footings founded at 42 in are fully compliant with bearing capacity and settlement (maximum settlement = 0.995 in on F3; maximum angular distortion = 0.00117 < 1/500). Total spread foundation cost is only $32,729. Ground improvement would cost $49,500 plus require mobilising a 3rd rig ($40,000), making ground improvement unjustifiably expensive.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | SPREAD | 105 x 105 | 21 | 439.2 | 5.74 | 5.75 | 0.730 | None | - | - | BEARING |
| F2 | SPREAD | 147 x 147 | 30 | 849.6 | 5.66 | 5.74 | 0.928 | None | - | - | BEARING |
| F3 | SPREAD | 171 x 171 | 33 | 1022.4 | 5.04 | 5.75 | 0.967 | None | - | - | SETTLEMENT |
| F4 | SPREAD | 141 x 141 | 27 | 705.6 | 5.11 | 5.74 | 0.950 | None | - | - | SETTLEMENT |
| F5 | SPREAD | 99 x 99 | 21 | 374.4 | 5.50 | 5.75 | 0.921 | None | - | - | BEARING |
| W1 | SPREAD | 129 x 288 | 24 | 1188.0 | 4.61 | 5.10 | 0.974 | None | - | Sliding FS=2.89, e=7.1in, Uplift FS=3.10 | SETTLEMENT |

---

## CR-P4

* **Building**: Apartments, Office
* **Occupancy Class / Factor of Safety**: Apartments, Office (FS = 3.0)
* **Concrete Specification**: f'c = 4000 psi, max w/cm = 0.50 (Exposure classes: F1, W1, C1, S1)
* **Foundation Decision**: `IMPROVED_SPREAD`
* **Governing Pad Constraint**: `SETTLEMENT`
* **Cost Comparison**: Spread-Only Alternative = $61,623.00 | Improved Alternative = $45,880.92
* **Decision Rationale**: Unimproved spread footings are theoretically feasible but require very wide footings (W1 B=22.25 ft, F3 B=19.0 ft) with high concrete and excavation costs totalling $61,623. Because RIG-2 is already mobilised to serve CR-P6, it has capacity to serve CR-P4 at zero additional mobilisation cost. Sizing footings over rammed aggregate piers (depth 9 ft) reduces footing sizes, limits settlements to <= 0.79 in and angular distortions to < 1/500 at an in-place cost of $45,881, yielding a direct savings of $15,742.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | IMPROVED_SPREAD | 96 x 96 | 21 | 384.3 | 6.00 | 6.37 | 0.649 | 4 x 9 ft | 15965 | - | BEARING |
| F2 | IMPROVED_SPREAD | 132 x 132 | 30 | 743.4 | 6.14 | 6.36 | 0.639 | 9 x 9 ft | 14334 | - | BEARING |
| F3 | IMPROVED_SPREAD | 144 x 144 | 30 | 894.6 | 6.21 | 6.35 | 0.740 | 9 x 9 ft | 16518 | - | BEARING |
| F4 | IMPROVED_SPREAD | 135 x 135 | 27 | 617.4 | 4.88 | 6.36 | 0.743 | 5 x 9 ft | 17769 | - | SETTLEMENT |
| F5 | IMPROVED_SPREAD | 87 x 87 | 18 | 327.6 | 6.23 | 6.35 | 0.588 | 4 x 9 ft | 14288 | - | BEARING |
| W1 | IMPROVED_SPREAD | 102 x 288 | 21 | 1039.5 | 5.10 | 5.24 | 0.589 | 14 x 9 ft | 12638 | Sliding FS=2.86, e=7.0in, Uplift FS=3.06 | BEARING |

---

## CR-P5

* **Building**: Warehouse
* **Occupancy Class / Factor of Safety**: Warehouse (FS = 2.5)
* **Concrete Specification**: f'c = 5000 psi, max w/cm = 0.40 (Exposure classes: F3, W1, C1, S0)
* **Foundation Decision**: `SPREAD`
* **Governing Pad Constraint**: `BEARING`
* **Cost Comparison**: Spread-Only Alternative = $16,774.35 | Improved Alternative = $42,000.00
* **Decision Rationale**: Stratum I is very stiff (Es = 250 ksf) and shallow (base at 4.5 to 5.5 ft). Compact spread footings founded at 42 in are governed by bearing capacity (q_net at 97-99% of q_allow) with settlements well within limits (0.56 to 0.81 in) and tiny angular distortions (< 0.00057). Total spread foundation cost is only $16,774, making it the most economical design on campus.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | SPREAD | 78 x 78 | 18 | 335.5 | 7.94 | 8.11 | 0.559 | None | - | - | BEARING |
| F2 | SPREAD | 108 x 108 | 24 | 649.0 | 8.01 | 8.05 | 0.722 | None | - | - | BEARING |
| F3 | SPREAD | 120 x 120 | 27 | 781.0 | 7.81 | 8.07 | 0.799 | None | - | - | BEARING |
| F4 | SPREAD | 99 x 99 | 21 | 539.0 | 7.92 | 8.05 | 0.805 | None | - | - | BEARING |
| F5 | SPREAD | 72 x 72 | 18 | 286.0 | 7.94 | 8.07 | 0.752 | None | - | - | BEARING |
| W1 | SPREAD | 72 x 288 | 15 | 907.5 | 6.30 | 6.41 | 0.753 | None | - | Sliding FS=2.76, e=6.8in, Uplift FS=2.97 | BEARING |

---

## CR-P6

* **Building**: Light Industrial, Public
* **Occupancy Class / Factor of Safety**: Light Industrial, Public (FS = 3.5)
* **Concrete Specification**: f'c = 4500 psi, max w/cm = 0.45 (Exposure classes: F1, W1, C1, S2)
* **Foundation Decision**: `IMPROVED_SPREAD`
* **Governing Pad Constraint**: `SETTLEMENT`
* **Cost Comparison**: Spread-Only Alternative = $148,200.00 | Improved Alternative = $81,939.10
* **Decision Rationale**: Stratum I residual soils are soft (Es = 95.0 ksf). Unimproved spread footings at the 42-in frost elevation exceed the 1.0-in total settlement limit and 1/500 angular distortion limit even at excessive dimensions (>25 ft). Deepening footings into Stratum II would require deep excavation and costly dewatering below the groundwater table (depth 8.5 ft), costing $148,200. Sizing footings over rammed aggregate piers (depth 11 ft, diameter 30 in) limits total settlement to <= 0.98 in and angular distortion to < 1/500 at a cost of $81,939, saving $66,261.

| Tag | Foundation Type | Dimensions B x L (in) | Thickness (in) | Demand P (kips) | q_net (ksf) | q_all (ksf) | Settlement (in) | Piers (count x depth) | Top Pier Stress (psf) | Stability Checks | Gov Constraint |
|---|---|---|---|---|---|---|---|---|---|---|---|
| F1 | IMPROVED_SPREAD | 135 x 135 | 27 | 622.2 | 4.92 | 5.46 | 0.909 | 5 x 11 ft | 17907 | - | BEARING |
| F2 | IMPROVED_SPREAD | 180 x 180 | 36 | 1203.6 | 5.35 | 5.48 | 0.882 | 12 x 11 ft | 15939 | - | BEARING |
| F3 | IMPROVED_SPREAD | 201 x 201 | 42 | 1448.4 | 5.16 | 5.50 | 0.979 | 12 x 11 ft | 17866 | - | BEARING |
| F4 | IMPROVED_SPREAD | 165 x 165 | 33 | 999.6 | 5.29 | 5.46 | 0.895 | 9 x 11 ft | 17038 | - | BEARING |
| F5 | IMPROVED_SPREAD | 120 x 120 | 24 | 530.4 | 5.30 | 5.48 | 0.817 | 5 x 11 ft | 16529 | - | BEARING |
| W1 | IMPROVED_SPREAD | 171 x 288 | 30 | 1683.0 | 4.92 | 4.97 | 0.877 | 16 x 11 ft | 16046 | Sliding FS=2.83, e=7.4in, Uplift FS=3.10 | BEARING |

---

