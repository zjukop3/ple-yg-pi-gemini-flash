```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01 DoD Building Code (1 September 2022 with Change 4, 17 December 2024)",
    "precedence": "Where two criteria set different limits for the same thing, the most restrictive requirement governs (EDS-26 clause 1.1 and Sheet G-001)"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42.0,
    "roof_ambient_c": 46.0,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.60,
    "solar_irradiance_w_m2": 1030.0
  },
  "sources": {
    "codes_of_record": "Drawing sheet G-001 and EDS-26 clause 1.1",
    "outdoor_design_dry_bulb_c": "NOAA station normals USW00003145 (highest daily normal maximum 106.8 F = 41.56 C, rounded up to 42 C per EDS-26 clause 5.4)",
    "roof_ambient_c": "Outdoor dry bulb + 4 K roof film allowance (42 C + 4 K = 46 C), coordinated with M-501-C Table and EDS-26 clause 5.4",
    "earth_ambient_c": "NOAA station normals USW00003145 annual mean of daily average temperature normals (76.00 F = 24.45 C) + 3 K = 27.45 C per EDS-26 clause 5.3.2",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T clause 2.2 for fluidized thermal backfill (0.60 K.m/W); rejected native soil 0.95 K.m/W per clause 2.1",
    "solar_irradiance_w_m2": "EDS-26 clause 5.4 (S = 1030 W/m2)"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (point of government ownership per WRPU service availability letter and UFC 3-501-01 clause 3-2.7.4.2)",
    "transformer_reset": "no",
    "feeder_chain_pct": {
      "chain_mcc1": 2.06,
      "chain_dp2_lp1": 2.48,
      "chain_dp3": 2.60
    },
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 107552.12,
    "termination_usd": 7838.28,
    "raceway_usd": 44660.1,
    "material_usd": 113661.14,
    "labor_usd": 46389.36,
    "total_usd": 160050.5
  },
  "duct_assignment": {
    "SE-1": ["D1", "D2", "D3", "D4", "D7", "D8"],
    "F-10": ["D9", "D10"],
    "F-05": ["E1", "E2"]
  },
  "mutual_heating_rise_k": 28.4
}
```

# Design Basis Narrative — Building 4210, Consolidated Support Facility

## 1. Codes of Record and Order of Precedence
This design basis governs the selection and sizing of all low-voltage power distribution conductors, raceways, equipment grounding conductors, and duct banks for project P-4210, Building 4210, Consolidated Support Facility, at Naval Support Activity Whitmore Ridge.
In accordance with Sheet G-001 (Code of Record and General Notes) and EDS-26 Rev 4 Clause 1.1, the codes of record fixed at the start of design on 14 July 2025 are:
1. **UFC 1-200-01, DoD Building Code** (1 September 2022, with Change 4 of 17 December 2024), which serves as the adopting document for all building and electrical criteria.
2. **International Building Code (IBC), 2024 Edition**, as adopted and amended by UFC 1-200-01.
3. **NFPA 70, National Electrical Code (NEC), 2023 Edition**. All references from IBC to NFPA 70 are directed by UFC 1-200-01 to UFC 3-501-01, which cites NFPA 70.
4. **UFC 3-501-01, Electrical Engineering** (27 November 2024).
5. **UFC 3-520-01, Interior Electrical Systems** (16 January 2025).
6. **UFC 1-200-02, High Performance and Sustainable Building Requirements**, adopting ASHRAE 90.1.
7. **Naval Support Activity Whitmore Ridge Electrical Design Standard EDS-26 Rev 4** (12 June 2026).

**Order of Precedence:** Where two criteria set different limits for the same design quantity, the most restrictive requirement governs. Where EDS-26 is silent, the governing UFC criteria control. In accordance with EDS-26 Clause 1.2, EDS-26 Rev 2 is superseded in its entirety, is retained for historical reference only, and has not been used for design.

## 2. Environmental Parameters and Provenance
- **Outdoor Design Dry-Bulb Temperature:** 42°C. Per EDS-26 Clause 5.4, this is derived from the NOAA daily normals (1991–2020) station record for Yuma MCAS, AZ US (Station USW00003145). The highest daily normal maximum temperature across the 366-day record is 106.8°F (41.56°C), which rounds up to the next whole degree Celsius as 42°C.
- **Roof Ambient Temperature:** 46°C. Formed by adding the 4 K roof film allowance of EDS-26 Clause 5.4 to the 42°C outdoor dry-bulb temperature (42°C + 4 K = 46°C). This exactly coordinates with mechanical coordination memorandum M-501-C.
- **Earth Ambient Temperature:** 27.45°C. Per EDS-26 Clause 5.3.2, this is the annual mean of daily average temperature normals from the NOAA station record (76.00°F = 24.45°C) plus 3 K (24.45°C + 3 K = 27.45°C).
- **Soil and Backfill Thermal Resistivity:** 0.60 K·m/W. Per geotechnical report GEO-4210-T Clause 2.2, both exterior duct banks (DB-1 and DB-2) are concrete-encased and surrounded by fluidized thermal backfill (sand-cement slurry, Section 31 23 23) for the entire width and depth of the trench. The thermal backfill resistivity is stable at 0.60 K·m/W at and below 4% moisture content. The native poorly graded sand with silt (SP-SM) has a design dryout resistivity of 0.95 K·m/W (GEO-4210-T Clause 2.1), but because the backfill envelope fully isolates the duct banks from native soil, the 0.95 K·m/W value was considered and rejected.
- **Concrete Encasement Thermal Resistivity:** 0.55 K·m/W per GEO-4210-T Clause 2.3 for red-dyed encasement concrete (Section 26 05 43).
- **Solar Irradiance:** 1030 W/m² per EDS-26 Clause 5.4, applied with an absorption coefficient alpha_s = 0.6 to sun-exposed cable tray CT-R1 on the roof.

## 3. Voltage-Drop Budget Allocation and Cumulative Path Rules
- **Calculation Starting Point:** Point of government ownership at the secondary lug compartment of pad-mounted utility transformer T-1, confirmed by Whitmore Ridge Public Utilities (WRPU) service letter and UFC 3-501-01 Clause 3-2.7.4.2. Initial voltage drop at T-1 secondary lugs is 0.00%.
- **Governing Limits:** Per UFC 3-501-01 Clause 3-2.7:
  - Feeders and service conductors: maximum 3.00% cumulative drop.
  - Branch circuits: maximum 3.00% individual drop.
  - Total cumulative drop at any utilization load: maximum 5.00%.
- **Transformer Reset Rule:** Per UFC 3-501-01 Clause 3-2.7.4.5.3, voltage drop through dry-type transformer K-13 due to transformer internal losses is zero for calculation purposes, and voltage drop percentages relative to nominal system voltage on primary and secondary buses match. Transformer voltage drop does NOT reset at K-13; downstream branch circuits inherit the full cumulative percentage drop accumulated on the upstream 480 V feeder chain.
- **Feeder Chains:**
  - **Chain 1 (T-1 -> MSB-1 -> MCC-1):** SE-1 drops 1.02% and F-01 drops 1.04%, resulting in a cumulative drop of 2.06% at MCC-1 (<= 3.00% feeder limit). This leaves a 2.94% budget for MCC-1 motor branch circuits (B-11 through B-15).
  - **Chain 2 (T-1 -> MSB-1 -> DP-2 -> K-13 -> LP-1):** SE-1 drops 1.02%, F-02 drops 0.27% (DP-2 cumulative = 1.29%), F-06 drops 0.14% (K-13 primary cumulative = 1.43%). Carrying 1.43% across K-13 to the secondary, F-07 (3 sets of 350 kcmil) drops 1.05%, yielding a cumulative drop of 2.48% at LP-1 (<= 3.00% feeder limit). This leaves 2.52% voltage drop budget for LP-1 208V branch circuits.
  - **Chain 3 (T-1 -> MSB-1 -> DP-3):** SE-1 drops 1.02% and F-05 (2 sets of 350 kcmil in DB-2) drops 1.58%, resulting in a cumulative drop of 2.60% at DP-3 (<= 3.00% feeder limit). Carrying 2.60% across DP-3's integral step-down transformer section per Clause 3-2.7.4.5.3 leaves a 2.40% budget for Building 4212 branch circuits (B-16 through B-18).
- **Branch Circuit Voltage-Drop Sizing:**
  - To satisfy the 5.00% cumulative limit at the utilization load, long branch circuits fed from LP-1 were increased above their ampacity baseline: B-01, B-03, B-04, B-05, and B-08 were increased to #8 AWG; B-02, B-06, and B-07 were increased to #6 AWG; B-09 was sized to #4 AWG.
  - In Building 4212, B-18 was increased to #8 AWG, achieving 4.57% cumulative drop at LTG-4A.
- **Dedicated Equipment Feeders Categorized as Branch Circuits:** Per UFC 3-501-01 Clause 3-2.7.4.3.2, feeders supplying chillers (F-04, F-12), packaged rooftop units (F-08, F-13), adjustable-speed drives (F-09), and elevators (F-11) are categorized as branch circuits for voltage drop compliance purposes, subject to the 3.00% individual and 5.00% cumulative limits. All dedicated equipment feeders easily meet these limits.
- **Fire Pump Feeder (F-03):** Sized per NFPA 70 Article 695 and EDS-26 Clause 4.6.3 to not exceed 15.0% drop at locked rotor (543 A) and 5.0% drop at full-load running (96 A). Feeder F-03 (1 set of 1/0 CU) achieves 1.26% cumulative drop running and 1.90% locked rotor (at 0.35 starting power factor), fully satisfying Article 695.

## 4. Service-Entrance Sizing and Duct Bank Thermal Optimization
- **Service Entrance (SE-1):** Sized to the MSB-1 main bus ampacity of 2000 A per EDS-26 Clause 2.2 and UFC 3-501-01 Clause 3-2.3.3. Six parallel sets of 500 kcmil copper in 5-inch EPC-40 ducts provide 6 x 362.9 A = 2177.4 A corrected ampacity under Neher-McGrath evaluation at 100% load factor.
- **Duct Bank DB-1 Assignment:** DB-1 contains 10 available ducts (D1–D10) and 2 reserved ducts (D11 spare, D12 existing site lighting). To minimize mutual heating between the heavily loaded service entrance and standby feeder F-10, SE-1 is assigned to ducts D1, D2, D3, D4, D7, and D8, while F-10 (2 sets of 350 kcmil) is assigned to bottom-row ducts D9 and D10. This layout maximizes physical separation, limiting the maximum mutual heating temperature rise across the bank to 28.4 K.
- **Duct Bank DB-2 Assignment:** DB-2 contains 3 available ducts (E1–E3) and 1 reserved duct (E4 communications). Feeder F-05 is assigned 2 sets of 350 kcmil occupying ducts E1 and E2. Mutual heating rise between E1 and E2 is only 1.61 K, yielding a corrected ampacity of 332.0 A per set (limited by 75°C terminations), well above the 200.0 A design current per set.

## 5. Material, Standardization, and Termination Decisions
- **Conductor Insulation and Specification:** Single-conductor XHHW-2, 90°C wet and dry, compact stranded Class B, basis of design Cascadia Wire and Cable Engineering Data Section 4. All equipment grounding conductors are green insulated THHN/THWN-2 copper per EDS-26 Clause 3.1.
- **Conductor Material:** Copper is specified throughout the project. Per UFC 3-520-01 Clause 3-6.3.1, conductors #6 AWG and smaller are strictly copper.
- **Size Standardization:** EDS-26 Clause 3.4.2 mandates that the completed design must not use more than five distinct phase-conductor sizes larger than #1 AWG across the entire project. The design standardizes on exactly four large sizes: **1/0 AWG, 300 kcmil, 350 kcmil, and 500 kcmil**. Sizes #1 AWG and smaller (#12, #10, #8, #6, #4, #3, #2) are exempt from this restriction.
- **Equipment Termination Compliance:**
  - Panelboard LP-1 has listed 60°C lug ratings (Equipment Schedule P-4210). In accordance with EDS-26 Clause 5.5, conductors connected to LP-1 are strictly limited to the 60°C ampacity column. Feeder F-07 utilizes 3 parallel sets of 350 kcmil (rated 278 A at 60°C per set = 834 A total), providing full compliance with the 780.66 A design current.
  - Equipment terminal physical limits are strictly respected: CH-1/CH-2 (max 350 kcmil) are served by 350 kcmil; RTU-1/RTU-2 (max 250 kcmil) are served by 1/0; FP-1 (max 250 kcmil) is served by 1/0; WLD-1 (max #2) is served by #2; CMP-1 (max #6) is served by #6; DW-1 (max #4) is served by #4.
- **Equipment Grounding Conductor Proportional Scaling:** Where phase conductors were increased above the ampacity baseline to satisfy voltage drop, the equipment grounding conductor was scaled up in the exact circular-mil ratio required by NFPA 70 Section 250.122(B) and EDS-26 Clause 5.7.

## 6. Installed Cost Ledger Summary
- The installed conductor package totals 33,828 feet of conductor (34,000 ft range), which does not reach the 38,000-foot campus quantity break threshold. Pricing reflects full project unit prices per the Cascadia Wire price list and P-4210 unit price book.
- Summary of installed cost:
  - Conductor: Material $89450.21, Labor $18101.91, Subtotal $107552.12
  - Terminations: Material $4118.94, Labor $3719.34, Subtotal $7838.28
  - Interior Rigid Steel Raceway: Material $20091.99, Labor $24568.11, Subtotal $44660.10
  - **Total Installed Package Cost:** $160050.50 (Material $113661.14, Labor $46389.36)
