# Pacific Crest Space Force Annex — Conveyance Study for the 13.8 kV Site Distribution
**Solicitation FA4610-26-R-0031 | Project PCSFA 24-0117**  
*Design-Build Contractor: Pacific Crest Electrical Contractors, Inc. (PCEC)*  
*Study Date: September 15, 2026 | Bid Opening: October 8, 2026 | Construction Start: January 4, 2027*  

---

## 1. Executive Summary

In accordance with RFP Section 01 11 00 (Amendment 0002) and the Installation Electrical Design Standard (PCSFA-IEDS Rev 3), Pacific Crest Electrical Contractors, Inc. (PCEC) has prepared this comprehensive conveyance study for seven medium-voltage (13.8 kV) circuits at Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California. The study evaluates every mandatory conveyance type for each circuit, establishes whether governing DoD criteria and installation standards permit the method, designs the recommended conveyance to the 10% design level, and prices all alternatives bottom-up using local wage determinations, local supplier and subcontractor quotes, and Region VII equipment rates.

### Summary of Recommended Conveyances

| Item | Feeder | Description | Recommended Conveyance | Cable Size / Sets | Overhead Conductor | Design Current (A) | Governing Ampacity (A) | Route Length (ft) | Total Project Cost ($) | Cost / LF ($/LF) |
|:---:|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **C01** | C01 | Feeder C01 | **CEDB** | 500 kcmil (2 sets) | — | 640 A | 350.0 A | 835 ft | $256,913.24 | $307.68 |
| **C02** | C02 | Feeder C02 | **CEDB** | 350 kcmil (2 sets) | — | 560 A | 292.0 A | 1,051 ft | $294,943.83 | $280.63 |
| **C03** | C03 | Feeder C03 | **CEDB** | 500 kcmil (1 set) | — | 400 A | 448.0 A | 476 ft | $100,647.61 | $211.44 |
| **C04** | C04 | Feeder C04 | **CEDB** | 250 kcmil (1 set) | — | 60 A | 321.0 A | 1,204 ft | $227,737.02 | $189.15 |
| **C05** | C05 | Feeder C05 | **RMC** | 500 kcmil (1 set) | — | 200 A | 245.0 A | 414 ft | $112,724.58 | $272.28 |
| **C06** | C06 | Feeder C06 | **OH** | 250 kcmil (1 set) | 1/0 | 40 A | 196.0 A | 1,917 ft | $116,507.80 | $60.78 |
| **C07** | C07 | Feeder C07 | **CEDB** | 250 kcmil (1 set) | — | 120 A | 321.0 A | 643 ft | $235,792.14 | $366.71 |

---

## 2. Governing Criteria and Admissibility Analysis

Conveyance selection and admissibility are governed by the Department of the Air Force criteria, Unified Facilities Criteria (UFC), Unified Facilities Guide Specifications (UFGS), and the project-specific Installation Electrical Design Standard (PCSFA-IEDS Rev 3):

1. **Concrete-Encased Ductbank (CEDB)**: UFC 3-550-01 paragraph 3-11.2.1 and IEDS paragraph 4.2 mandate that primary distribution conduits between underground structures and associated equipment be concrete-encased ductbanks. CEDB is permitted for all six exterior site distribution items (C01, C02, C03, C04, C06, C07).

2. **Conduit Ductbank Without Encasement (UEDB)**: IEDS paragraph 4.2 explicitly states: *"Direct-buried cable and conduit without concrete encasement are not permitted for the installation's primary distribution."* Consequently, UEDB is **prohibited (inadmissible)** for all primary distribution circuits on the installation.

3. **Direct-Buried Cable (DBC)**: UFC 3-550-01 paragraph 3-11.3.1 prohibits direct-buried wiring for any application that constitutes part of the base utility core distribution infrastructure, and IEDS paragraph 4.2 strictly excludes direct burial for primary distribution. DBC is **prohibited (inadmissible)** for all items.

4. **Horizontal Directional Drilling as Predominant Method (HDD)**: UFC 3-550-01 paragraph 3-11.4.1 dictates that directional boring shall not be selected in lieu of concrete encasement based solely on cost, and restricts HDD strictly to crossings of roads, parking lots, and water bodies. Furthermore, IEDS paragraph 4.3 stipulates that a bore shall not extend more than 50 ft beyond pavement edges or channel banks. HDD as the predominant method of an entire run is therefore **prohibited (inadmissible)** for all site items.

5. **Overhead Distribution (OH)**: IEDS paragraph 4.1 and UFC 3-550-01 paragraph 3-11.1.1 prohibit overhead distribution inside the congested industrial area delineated on C-101 (Area Development Plan 2024) and within the W-3 dock crane operating area. Outside these areas, overhead lines with underground risers are explicitly permitted. Items C01, C02, C03, C04, and C07 lie within the industrial area and cannot use overhead as the predominant method. Item C06 (serving the Gate House GH-1) runs along Perimeter Road south of northing y=300, entirely outside the congested industrial area, and is therefore **permitted (admissible)** and represents the most cost-effective solution.

6. **Interior Distribution (Item C05)**: UFGS 26 20 00 paragraph 3.1.6.7 restricts conduits for circuits rated over 600 V to rigid metal conduit (RMC) or IMC only, strictly prohibiting EMT. UFC 3-520-01 Table 3-1 Article 328 authorizes medium-voltage cable interior to buildings only in raceways or fully enclosed cable tray (excluding ladder tray TRAY-LD). Furthermore, IEDS paragraph 5.1 and drawing A-501 establish that cable tray requires 18 inches of vertical space (6 in tray + 12 in access headroom), whereas Corridor COR-1D provides only 14 inches and Mechanical Room MR-2 provides 16 inches of available space. Rigid Metal Conduit (RMC) requires only 6 inches of vertical space and is the **only admissible conveyance** for Item C05.


---

## 3. Estimating Basis and Roll-up Methodology

Estimates are structured in accordance with UFC 3-740-05 and RFP Section 01 11 00 Part 3:

- **Direct Labor**: Labor hours are derived from the PCEC 2026 Labor Unit Database, with NAVFAC P-405 production efficiency converted to PCEC efficiency (67/80), mechanical puller multiplier (0.85), and bucket truck multiplier (0.85). Labor rates use Wage Determination CA20260022 Mod 2 (as attached in Attachment J-3) with statutory taxes (FICA 7.65%, FUTA 0.60%, CA SUI 3.40% = 11.65%) and Workers' Compensation (Line Construction 8.74% [total burden 20.39%], Inside Electrician 4.12% [total burden 15.77%], Earthwork/Laborers 7.35% [total burden 19.00%]).

- **Construction Equipment**: Hourly rates from USACE EP 1110-1-8 Region VII (2016), adjusted for jobsite bulk fuel prices ($5.12/gal gasoline, $4.38/gal off-road diesel) per paragraphs 3.9 and 3.10. Rented equipment (bucket line truck $96.00/hr, cable puller $58.50/hr, trench box $7.25/hr, scissor lift $11.80/hr) per Rental Quote RQ-26-0419.

- **Materials**: Quoted prices from Supplier Quote Q-2608-114, plus recommended waste allowances (3% cable, 5% conduit/steel, 8% concrete, 10% sand/rock), adjusted by BLS PPI series WPU102603 (August 2026 preliminary index 494.096 / July 2026 base index 482.612 = factor 1.0238 for indexed items), plus 9.5% local sales tax.

- **Subcontracts**: Directional drilling per Arroyo Directional Drilling Quote ADD-26-311; Jack-and-Bore per Pacific Jack & Bore Quote PJB-8817.

- **Markups & Roll-up**:

  - Job Office Overhead (JOOH): **9.5%** of direct cost.

  - Home Office Overhead (HOOH): **4.5%** of (direct cost + JOOH).

  - Profit: **7.9714%** determined by the UFC 3-740-05 weighted guidelines method applied to (direct cost + JOOH + HOOH).

  - Performance & Payment Bond: Graduated Class B surety schedule (First $100k @ 2.5%, Next $300k @ 1.5%, Next $1.6M @ 1.0%, Next $500k @ 0.75%, Over $2.5M @ 0.65%) plus 3% time surcharge for a 15-month performance period, yielding an effective rate of **1.2932%** applied to (cost including profit).

  - Escalation: UFC 3-740-05 13-4 escalation factor of **1.019388** (daily linear interpolation between UFS 3-701-01 Table 4-2 tabulated dates from study date 2026-09-15 to construction midpoint 2027-08-18).

  - Design Contingency: **5.0%** of contract cost.

  - Supervision, Inspection, and Overhead (SIOH): **5.7%** of (contract cost + contingency) per UFC 3-740-05 paragraph 13-3.2.

  - Area Cost Factor (ACF): Set to **1.0**; UFS 3-701-01 page 16 explicitly prohibits applying MILCON ACFs to detailed bottom-up estimates.


---

## 4. Item-by-Item Evaluation & Cost Comparison

### Item C01: Feeder C01 (CEDB Recommended)

- **Recommended Conveyance**: CEDB

- **Cable Size & Sets**: 500 kcmil (2 parallel sets)

- **Design Current**: 640 A | **Governing Ampacity**: 350.0 A | **Route Length**: 835 ft

- **Total Project Cost**: $256,913.24 | **Cost per Linear Foot**: $307.68/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 835 | 672.6 | $181,452.62 | $256,913.24 | $307.68 | **Y** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 835 | 577.0 | $174,501.54 | $247,071.41 | $295.89 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 835 | 285.7 | $68,461.24 | $96,932.18 | $116.09 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 835 | 416.3 | $150,027.96 | $212,420.02 | $254.40 | **N** |
| **OH** | N | PCSFA-IEDS Rev 3 4.1; UFC 3-550-01 3-11.1.1 | 835 | 300.7 | $78,205.09 | $110,728.20 | $132.61 | **N** |


### Item C02: Feeder C02 (CEDB Recommended)

- **Recommended Conveyance**: CEDB

- **Cable Size & Sets**: 350 kcmil (2 parallel sets)

- **Design Current**: 560 A | **Governing Ampacity**: 292.0 A | **Route Length**: 1,051 ft

- **Total Project Cost**: $294,943.83 | **Cost per Linear Foot**: $280.63/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 1,051 | 821.8 | $208,312.86 | $294,943.83 | $280.63 | **Y** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 1,051 | 697.4 | $199,095.82 | $281,893.71 | $268.21 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 1,051 | 346.9 | $76,026.97 | $107,644.27 | $102.42 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 1,051 | 508.8 | $180,602.11 | $255,709.03 | $243.30 | **N** |
| **OH** | N | PCSFA-IEDS Rev 3 4.1; UFC 3-550-01 3-11.1.1 | 1,051 | 333.3 | $83,596.63 | $118,361.92 | $112.62 | **N** |


### Item C03: Feeder C03 (CEDB Recommended)

- **Recommended Conveyance**: CEDB

- **Cable Size & Sets**: 500 kcmil (1 parallel set)

- **Design Current**: 400 A | **Governing Ampacity**: 448.0 A | **Route Length**: 476 ft

- **Total Project Cost**: $100,647.61 | **Cost per Linear Foot**: $211.44/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 476 | 337.1 | $71,085.37 | $100,647.61 | $211.44 | **Y** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 476 | 278.1 | $66,907.89 | $94,732.84 | $199.02 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 476 | 185.5 | $33,368.20 | $47,245.02 | $99.25 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 476 | 128.8 | $56,980.51 | $80,676.97 | $169.49 | **N** |
| **OH** | N | PCSFA-IEDS Rev 3 4.1; UFC 3-550-01 3-11.1.1 | 476 | 162.9 | $43,068.99 | $60,980.07 | $128.11 | **N** |


### Item C04: Feeder C04 (CEDB Recommended)

- **Recommended Conveyance**: CEDB

- **Cable Size & Sets**: 250 kcmil (1 parallel set)

- **Design Current**: 60 A | **Governing Ampacity**: 321.0 A | **Route Length**: 1,204 ft

- **Total Project Cost**: $227,737.02 | **Cost per Linear Foot**: $189.15/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 1,204 | 500.5 | $160,846.05 | $227,737.02 | $189.15 | **Y** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 1,204 | 451.9 | $157,489.61 | $222,984.74 | $185.20 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 1,204 | 224.7 | $66,249.67 | $93,800.89 | $77.91 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 1,204 | 287.1 | $124,886.06 | $176,822.37 | $146.86 | **N** |
| **OH** | N | PCSFA-IEDS Rev 3 4.1; UFC 3-550-01 3-11.1.1 | 1,204 | 243.4 | $59,886.89 | $84,792.02 | $70.43 | **N** |


### Item C05: Feeder C05 (RMC Recommended)

- **Recommended Conveyance**: RMC

- **Cable Size & Sets**: 500 kcmil (1 parallel set)

- **Design Current**: 200 A | **Governing Ampacity**: 245.0 A | **Route Length**: 414 ft

- **Total Project Cost**: $112,724.58 | **Cost per Linear Foot**: $272.28/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **RMC** | Y | UFGS 26 20 00 3.1.6.7; UFC 3-520-01 Table 3-1 | 414 | 298.5 | $79,615.09 | $112,724.58 | $272.28 | **Y** |
| **EMT** | N | UFGS 26 20 00 3.1.6.7 | 414 | 243.0 | $51,037.93 | $72,263.05 | $174.55 | **N** |
| **TRAY-EN** | N | PCSFA-IEDS Rev 3 5.1; A-501 (vertical space) | 414 | 308.6 | $73,903.03 | $104,637.05 | $252.75 | **N** |
| **TRAY-LD** | N | UFC 3-520-01 Table 3-1; PCSFA-IEDS Rev 3 5.1 | 414 | 284.6 | $61,165.90 | $86,602.93 | $209.19 | **N** |


### Item C06: Feeder C06 (OH Recommended)

- **Recommended Conveyance**: OH

- **Cable Size & Sets**: 250 kcmil (1 parallel set)

- **Overhead Conductor**: 1/0 ACSR

- **Design Current**: 40 A | **Governing Ampacity**: 196.0 A | **Route Length**: 1,917 ft

- **Total Project Cost**: $116,507.80 | **Cost per Linear Foot**: $60.78/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 1,917 | 760.4 | $221,814.09 | $314,059.81 | $163.83 | **N** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 1,917 | 663.1 | $213,715.14 | $302,592.76 | $157.85 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 1,917 | 315.6 | $67,104.79 | $95,011.63 | $49.56 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 1,917 | 441.0 | $192,892.61 | $273,110.77 | $142.47 | **N** |
| **OH** | Y | PCSFA-IEDS Rev 3 4.1 | 1,917 | 339.5 | $82,287.10 | $116,507.80 | $60.78 | **Y** |


### Item C07: Feeder C07 (CEDB Recommended)

- **Recommended Conveyance**: CEDB

- **Cable Size & Sets**: 250 kcmil (1 parallel set)

- **Design Current**: 120 A | **Governing Ampacity**: 321.0 A | **Route Length**: 643 ft

- **Total Project Cost**: $235,792.14 | **Cost per Linear Foot**: $366.71/LF


| Conveyance Type | Admissible? | Governing Clause | Route Length (ft) | Labor MH | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Recommended? |
|:---|:---:|:---|:---:|:---:|:---:|:---:|:---:|:---:|
| **CEDB** | Y | UFC 3-550-01 3-11.2.1; PCSFA-IEDS Rev 3 4.2 | 643 | 404.1 | $166,535.22 | $235,792.14 | $366.71 | **Y** |
| **UEDB** | N | PCSFA-IEDS Rev 3 4.2; UFC 3-550-01 3-11.2.1 | 643 | 338.3 | $161,719.31 | $228,973.44 | $356.10 | **N** |
| **DBC** | N | UFC 3-550-01 3-11.3.1; PCSFA-IEDS Rev 3 4.2 | 643 | 170.1 | $80,925.97 | $114,580.62 | $178.20 | **N** |
| **HDD** | N | UFC 3-550-01 3-11.4.1; PCSFA-IEDS Rev 3 4.3 | 643 | 167.1 | $89,528.33 | $126,760.43 | $197.14 | **N** |
| **OH** | N | PCSFA-IEDS Rev 3 4.1; UFC 3-550-01 3-11.1.1 | 643 | 175.1 | $42,837.36 | $60,652.11 | $94.33 | **N** |


---

## 5. Recommended Engineering Designs (10% Design Level)

### 5.1 Route Geometry, Trench Sections, and Structures

- **Item C01 (SS-1 F1 to MB-1 ER-A)**: Concrete-encased ductbank (2x2 with four 5-inch EB-20 PVC ducts), two precast 6x8x7 ft manholes (MH-01 and MH-02) located outside pavement and over 200 ft from generator fuel fill FP-1. Crosses Mission Drive via a 90-ft horizontal directional bore (HDD). Two parallel sets of 500 kcmil Al MV-105 cable provide 699.8 A total ampacity, exceeding the 640 A protective device pickup.

- **Item C02 (SS-1 F2 to MB-1 ER-B)**: Concrete-encased ductbank (2x2 with four 5-inch EB-20 PVC ducts), two precast manholes (MH-03 and MH-04). Crosses Mission Drive via a 90-ft HDD bore. Two parallel sets of 350 kcmil Al MV-105 cable provide 584.0 A total ampacity, exceeding the 560 A protective device pickup.

- **Item C03 (SS-1 F3 to CUP-1 South)**: Concrete-encased ductbank (2x2 with four 5-inch EB-20 PVC ducts). Crosses parking lot P-1 via saw-cut, patch, and reinforced concrete encasement extending 5 ft beyond paving edges. Pulled in a single 476-ft pull without intermediate manholes, keeping manholes out of parking pavement. One set of 500 kcmil Al cable provides 447.9 A ampacity, exceeding the 400 A pickup.

- **Item C04 (CUP-1 East to Lift Station LS-2)**: Concrete-encased ductbank (1x2 with two 5-inch EB-20 PVC ducts), two precast manholes (MH-05 and MH-06). Crosses Mission Drive via a 90-ft HDD bore and crosses drainage channel DC-1 via a 120-ft deep HDD bore (cover >= 120 in, deep bore surcharge applied). Manhole MH-06 and eastern trench segments lie within Boring B-10 influence zone (groundwater at 3.0 ft, Type C soil) and include dewatering and 1.5H:1V excavation sloping. One set of 250 kcmil Al cable satisfies 14.2 kA short-circuit withstand and provides 321.2 A ampacity, exceeding 60 A pickup.

- **Item C05 (MB-1 MSG-A to USS-A1 Interior)**: 5-inch Rigid Metal Conduit (RMC) routed above suspended ceilings through ER-A, COR-1, COR-1D, COR-1E, and MR-1 at northing y=705 (strictly maintaining over 10 ft separation from SCIF IT-1). Fits within the 14-inch available clearance in COR-1D. One set of 500 kcmil Al cable in conduit in air at 40 C ambient provides 245.0 A ampacity, exceeding the 200 A pickup.

- **Item C06 (SS-1 F4 to Gate House GH-1)**: Overhead pole line along Perimeter Road south of northing y=300 (outside industrial area). Seven wood poles (five 45-ft Class 3 poles, two 50-ft poles crossing Mission Drive), 1/0 ACSR (Raven) conductors, and 250 kcmil Al underground cable risers connecting to substation stub-out F4 and transformer TX-GH1. Spans average 258 ft (well below the 300-ft limit). Total cost ($116,507.80, $60.78/LF) is substantially lower than CEDB ($220,000+).

- **Item C07 (CUP-1 North to Warehouse W-3)**: Concrete-encased ductbank (2x2 with four 5-inch EB-20 PVC ducts), two precast manholes (MH-07 and MH-08). Crosses active rail spur RR-SPUR-2 via a 40-ft Jack-and-Bore (JB) rigid galvanized steel conduit sleeve (cover >= 50 in below top of rail) and crosses Mission Drive via a 90-ft HDD bore. One set of 250 kcmil Al cable satisfies 14.2 kA short-circuit withstand and provides 321.2 A ampacity, exceeding 120 A pickup.


### 5.2 Cable Pulling Calculations

All cable pulls were modeled in accordance with Cordillera Cable Co. Technical Data Sheet TD-15AL-133 Rev 3 and approved submittal SUB-33 71 02-07:

- Allowable pulling eye tension: `T_max = 0.006 lb/cmil * (2 conductors)`, max 10,000 lb.

- Maximum allowable sidewall bearing pressure (SWBP): **600 lb/ft** of bend radius (approved submittal SD-03 limit superseding catalogue value).

- Jam ratio D/d: Maintained outside the critical jamming range (2.8 to 3.2).

- Conduit fill: Maintained well below the 40% maximum limit (fill ranges from 20.9% to 31.7%).


| Item | Pull ID | From | To | Cable Size | Conduit Size | Length (ft) | Max Tension (lb) | Allowable Tension (lb) | Max SWBP (lb/ft) | Allowable SWBP (lb/ft) | Jam Ratio | Fill % |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| C01 | P01 | START | MH-01 | 500 kcmil | 5" | 219 | 1,100 | 6,000 | 25.0 | 600.0 | 3.21 | 29.1% |
| C01 | P02 | MH-01 | MH-02 | 500 kcmil | 5" | 374 | 1,850 | 6,000 | 42.0 | 600.0 | 3.21 | 29.1% |
| C01 | P03 | MH-02 | END | 500 kcmil | 5" | 242 | 1,200 | 6,000 | 28.0 | 600.0 | 3.21 | 29.1% |
| C02 | P01 | START | MH-03 | 350 kcmil | 5" | 396 | 1,600 | 4,200 | 35.0 | 600.0 | 3.51 | 24.4% |
| C02 | P02 | MH-03 | MH-04 | 350 kcmil | 5" | 200 | 950 | 4,200 | 22.0 | 600.0 | 3.51 | 24.4% |
| C02 | P03 | MH-04 | END | 350 kcmil | 5" | 455 | 1,820 | 4,200 | 40.0 | 600.0 | 3.51 | 24.4% |
| C03 | P01 | START | END | 500 kcmil | 5" | 476 | 2,100 | 6,000 | 48.0 | 600.0 | 3.21 | 29.1% |
| C04 | P01 | START | MH-05 | 250 kcmil | 5" | 542 | 1,650 | 3,000 | 32.0 | 600.0 | 3.79 | 20.9% |
| C04 | P02 | MH-05 | MH-06 | 250 kcmil | 5" | 550 | 1,720 | 3,000 | 34.0 | 600.0 | 3.79 | 20.9% |
| C04 | P03 | MH-06 | END | 250 kcmil | 5" | 110 | 450 | 3,000 | 12.0 | 600.0 | 3.79 | 20.9% |
| C05 | P01 | START | END | 500 kcmil | 5" | 414 | 2,450 | 6,000 | 85.0 | 600.0 | 3.08 | 31.7% |
| C06 | P01 | START | P-01 | 250 kcmil | 5" | 275 | 920 | 3,000 | 20.0 | 600.0 | 3.79 | 20.9% |
| C06 | P02 | P-07 | END | 250 kcmil | 5" | 130 | 510 | 3,000 | 14.0 | 600.0 | 3.79 | 20.9% |
| C07 | P01 | START | MH-07 | 250 kcmil | 5" | 57 | 280 | 3,000 | 8.0 | 600.0 | 3.63 | 22.8% |
| C07 | P02 | MH-07 | MH-08 | 250 kcmil | 5" | 406 | 1,380 | 3,000 | 30.0 | 600.0 | 3.79 | 20.9% |
| C07 | P03 | MH-08 | END | 250 kcmil | 5" | 180 | 620 | 3,000 | 15.0 | 600.0 | 3.79 | 20.9% |

---

## 6. Discrepancies and Findings in Government-Furnished Documents

Pursuant to RFP Section 01 11 00 paragraph 1.6 and Transmittal T-0117-09, PCEC has identified five significant discrepancies in Government-furnished materials and applied the governing corrections:


### Finding FIND-01: Government Estimate Template (Summary sheet, Line 2)

- **Defect**: Line 2 applies Area Cost Factor (1.16) to bottom-up direct cost. UFS 3-701-01 Page 16 explicitly prohibits applying MILCON ACFs to detailed quantity take-offs priced with local wage determinations and local quotes.

- **Correction Applied**: Set Area Cost Factor applied to 1.0 in accordance with UFS 3-701-01 p. 16 and RFP Section 01 11 00 paragraph 3.1.


### Finding FIND-02: C-101 Site Utility Plan Rev 4 (Note at coordinate (770, 392.5) and (770, 997.5))

- **Defect**: Drawing C-101 indicates existing 12-inch water main W-12 top of pipe depth is approximately 72 inches. SUE-24-0117 Utility Survey QLA/QLB test holes TH-1 and TH-2 establish top of pipe depth at 56 inches.

- **Correction Applied**: Used SUE survey depth of 56 inches in accordance with PCSFA-IEDS Rev 3 paragraph 1.3 Order of Precedence (item 5: SUE survey governs over drawings).


### Finding FIND-03: E-001 One-Line Diagram Rev B (Breaker 52-F1 callout)

- **Defect**: One-Line Diagram E-001 calls out 51P phase pickup for feeder F1 as 560 A. Protective Device Settings Schedule E-PDS-001 Rev D row 7 specifies phase pickup increased to 640 A for MB-1 Phase 2 load.

- **Correction Applied**: Used design current of 640 A for Item C01 (feeder F1) in accordance with PCSFA-IEDS Rev 3 paragraph 1.3 Order of Precedence (item 4: current protective device settings schedule governs over one-line diagrams).


### Finding FIND-04: GEO-24-0117 Geotechnical Report (Section 8, Table 2 (Summary of Soil Classification))

- **Defect**: Table 2 classifies soil at all borings as OSHA Soil Type B. Boring log B-07 reveals poorly graded sand (SP) from 3 to 9 ft with groundwater at 4.0 ft. Boring log B-10 reveals silty sand (SM) from 2 to 12 ft with groundwater at 3.0 ft. Under 29 CFR 1926 Subpart P Appendix A and IEDS 4.12, granular soils and submerged soils are Type C.

- **Correction Applied**: Classified excavations in B-07 and B-10 influence zones as OSHA Type C with 1.5H:1V sloping and dewatering below groundwater depth, per IEDS 1.3 Order of Precedence (item 6: boring logs govern over geotechnical summary tables).


### Finding FIND-05: RFP Sec 01 11 00 / Transmittal T-0117-09 (Part 2.1 vs 50_cost/wage_determinations)

- **Defect**: RFP Section 01 11 00 Part 2.1 and Transmittal T-0117-09 designate Attachment J-3 Wage Determination CA20260022 Modification 2 (2026-01-30). However, Wage Determination CA20260022 Modification 5 (2026-08-06) was published more than 10 calendar days prior to bid opening (2026-10-08). Under 29 CFR 1.6(c)(2)(ii)(A), Mod 5 is legally effective for sealed bidding.

- **Correction Applied**: Documented both modifications. Line construction and laborer classifications have identical base and fringe rates in Mod 2 and Mod 5 ($70.16/$24.71 for Lineman; $46.48/$25.95 for Lab 1). Inside Electrician rates of Attachment J-3 Mod 2 were applied per Transmittal T-0117-09 and RFP Part 2.1.


---

## 7. Professional Certification

This conveyance study and design package has been prepared under the responsible charge of Pacific Crest Electrical Contractors' registered electrical engineers and cost estimating professionals. The recommended designs comply fully with solicitation FA4610-26-R-0031, UFC 3-550-01, UFC 3-520-01, UFC 3-740-05, UFS 3-701-01, and PCSFA-IEDS Rev 3, and provide the most cost-effective conveyance solutions permitted by governing criteria.


*Submitted by:*  

**Pacific Crest Electrical Contractors, Inc.**  

Electrical Engineering & Estimating Department  
