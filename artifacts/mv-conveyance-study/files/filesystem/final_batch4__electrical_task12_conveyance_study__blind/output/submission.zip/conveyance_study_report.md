# Pacific Crest Space Force Annex — 13.8 kV Site Distribution Conveyance Study
## Solicitation FA4610-26-R-0031 | Project PCSFA 24-0117
**Prepared by:** Design-Build Contractor Electrical Engineering & Cost Estimating Team  
**Date:** 2026-09-15 | **Submittal:** 35% Design Conveyance Study Package  

---

## 1. Executive Summary

This conveyance study has been prepared in accordance with RFP Section 01 11 00 (Amendment 0002) for the Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California. The study evaluates medium-voltage distribution conveyance alternatives for seven primary circuits (Items C01 through C07) operating at 13.8 kV, 3-phase, 3-wire, resistance grounded. The conveyance types evaluated include concrete-encased ductbank (CEDB), unencased conduit ductbank (UEDB), direct-buried cable (DBC), horizontal directional drilling (HDD), and overhead pole lines (OH) for exterior distribution, as well as rigid metal conduit (RMC), electrical metallic tubing (EMT), enclosed solid-bottom cable tray (TRAY-EN), and ladder cable tray (TRAY-LD) for interior distribution inside Building MB-1.

For each circuit, governing Department of Defense criteria (UFC 3-550-01, UFC 3-520-01, UFC 3-501-01), the installation standard (PCSFA-IEDS Rev 3), environmental/site physical constraints, and full bottom-up cost estimates prepared per UFC 3-740-05 were analyzed. The recommended conveyance for each item is the code-admissible alternative that minimizes total project cost.

### Table 1-1: Study Summary & Recommended Conveyance per Item

| Item ID | Feeder | From | To | Recommended Type | Cable Size | Sets | OH Conductor | Design Current (A) | Governing Ampacity (A) | Route Length (ft) | Total Project Cost | Cost / LF |
|:-------:|:------:|:----:|:--:|:----------------:|:----------:|:----:|:------------:|:------------------:|:----------------------:|:-----------------:|:------------------:|:---------:|
| C01 | F1 | SS1-F1 | MB1-ERA | **CEDB** | 500 kcmil | 2 | — | 640 A | 360.4 A | 930 ft | **$272,541.19** | **$293.06** |
| C02 | F2 | SS1-F2 | MB1-ERB | **CEDB** | 350 kcmil | 2 | — | 560 A | 299.1 A | 1,210 ft | **$352,861.04** | **$291.62** |
| C03 | F3 | SS1-F3 | CUP1-S | **CEDB** | 500 kcmil | 1 | — | 400 A | 461.3 A | 490 ft | **$91,898.40** | **$187.55** |
| C04 | CF-2 | CUP1-E | TX-LS2 | **CEDB** | 250 kcmil | 1 | — | 60 A | 330.5 A | 1,215 ft | **$270,040.67** | **$222.26** |
| C05 | A-3 | MSG-A | USS-A1 | **RMC** | 500 kcmil | 1 | — | 200 A | 245 A | 400 ft | **$103,813.58** | **$259.53** |
| C06 | F4 | SS1-F4 | TX-GH1 | **OH** | 250 kcmil | 1 | 1/0 AWG | 40 A | 196 A | 1,970 ft | **$129,511.61** | **$65.74** |
| C07 | CF-1 | CUP1-N | TX-W3 | **CEDB** | 250 kcmil | 1 | — | 120 A | 330.5 A | 680 ft | **$185,199.17** | **$272.35** |

**Total Recommended Project Cost (All 7 Circuits):** **$1,405,865.66**  

---

## 2. Regulatory Criteria & Basis of Design

### 2.1 Order of Precedence
In accordance with PCSFA-IEDS Rev 3 Section 1.3, the following precedence was strictly enforced whenever project documents exhibited differences:
1. **PCSFA-IEDS Rev 3 (2026-05-01):** Project-specific installation standard requirements, where stricter than governing criteria.
2. **Unified Facilities Criteria (UFC):** UFC 3-550-01 (Change 3, 2019), UFC 3-520-01 (2025), UFC 3-501-01 (2024), UFC 3-301-01 (Change 5, 2023), and UFC 3-740-05 (Change 1, 2025). Stricter limit governs between UFC and UFGS.
3. **Approved Project Submittals:** Approved cable submittal SUB-33 71 02-07 (Code A approval dated 2026-08-21), governing over manufacturer general catalogue data.
4. **Current Protective Device Settings Schedule:** Revision D (2026-06-30), governing over one-line diagrams.
5. **Subsurface Utility Engineering (SUE) Survey:** SUE-24-0117 Quality Level B, governing over record drawings.
6. **Geotechnical Boring Logs & Laboratory Data:** GEO-24-0117 individual logs B-01 through B-12, governing over summary narrative tables.
7. **Arborist Tree Survey:** TS-24-0117, governing over topographic drawings.

### 2.2 Electrical Distribution System Parameters
- **System Voltage & Configuration:** 13.8 kV, 3-phase, 3-wire, resistance grounded system.
- **Cable Specifications:** Single-conductor Type MV-105, cross-linked polyethylene (XLPE) insulation, 133% insulation level (220 mils), helically applied bare copper tape shield with overlap, black PVC jacket, compact stranded aluminum conductor (alloy 1350) per NEMA WC 74 and Cordillera Cable Co. TD-15AL-133 Rev 3.
- **Ductbank Conduits:** Type EB-20 PVC encased in concrete for underground ductbanks, minimum 5-inch diameter, with 3 inches minimum concrete separation between ducts and 3 inches concrete encasement on all sides (UFC 3-550-01 3-11.2.1, 3-11.2.2). One bare 4/0 AWG copper ground conductor per ductbank.
- **Spare Conduits:** At least 1/3 of the ductbank contains empty spare conduits (minimum 1 spare conduit), rounded up to whole ducts (UFC 3-550-01 3-11.2.2; PCSFA-IEDS 4.8). 1-circuit feeders utilize 2-duct banks (1 active, 1 spare); 2-circuit feeders utilize 4-duct banks (2 active, 2 spare).
- **Ampacity Evaluation:** Based on Cordillera TD-15AL-133 ampacity tables using 25°C design earth ambient temperature, soil thermal resistivity (rho) from the nearest boring log at 3 ft depth, and daily load factors of 100% for mission feeders F1/F2 and 75% for all other feeders (PCSFA-IEDS 2.3, 4.6). Per Note 5, lookup values use the next higher tabulated rho and depth, without interpolation.
- **Short-Circuit Withstand:** Cable conductor capability for the backup (breaker-failure) clearing time of 0.5 s must equal or exceed the available bus symmetrical fault current (16.5 kA at SS-1, 15.8 kA at MSG-A, 14.2 kA at SWG-C1). From TD-15AL-133 Table 4.10, the minimum conductor size to withstand 16.5 kA and 14.2 kA at 0.5 s is **250 kcmil** (rated 16.6 kA).

### 2.3 Physical, Site, and Environmental Constraints
- **Congested Industrial Area (ADP 2024):** Overhead lines are strictly prohibited within the delineated industrial area boundary on C-101 (PCSFA-IEDS 4.1). Outside this boundary, overhead lines are permitted with underground risers to buildings and equipment pads.
- **Pavement Open-Cut Restrictions:** Perimeter Road, Mission Drive, and the MB-1 access drive are designated 'DO NOT OPEN CUT'. They must be crossed via trenchless technology (HDD or Jack-and-Bore) per PCSFA-IEDS 4.3 and UFC 3-550-01 3-11.2.2. Parking Lot P-1 and the CUP-1 service yard may be saw-cut and patched, provided ductbanks beneath them are reinforced with steel extending at least 5 ft beyond pavement edges (UFGS 33 71 02 3.7.8.1).
- **Drainage Channel DC-1 (USACE Section 404):** No open cut is permitted within Channel DC-1 or its 25-ft buffer zone. Bores beneath DC-1 must have minimum 120-inch (10-ft) ground cover (PCSFA-IEDS 4.7). Overhead lines spanning DC-1 must maintain all poles completely outside the channel buffer limit (PCSFA-IEDS 4.9).
- **Active Rail Spur RR-SPUR-2:** Conduits crossing RR-SPUR-2 must be installed via jacked rigid galvanized steel (RGS) conduit (for crossing lengths <= 50 ft) with the top of conduit at least 50 inches below the top of rail (PCSFA-IEDS 4.5).
- **Tree Protection Zones (TPZ):** Retained trees identified in arborist survey TS-24-0117 have protected radial zones of 1 ft per inch of trunk DBH. No trenching, structures, or poles are permitted within TPZs (PCSFA-IEDS 4.14). Trees marked for removal (T-205, T-210) are unrestricted.
- **Substation Bus Redundancy:** Feeders from SS-1 Bus A (F1, F3) and Bus B (F2, F4) must maintain independent ductbanks and underground structures with at least 20 ft centerline separation, except within 50 ft of substation fence or building entries (PCSFA-IEDS 4.4).
- **Manhole Clearances (Air Force Specific):** Manholes must not be placed in pavement. Furthermore, manholes must maintain minimum separations of 50 ft from pavement edges and 200 ft from generator fueling point FP-1 (UFC 3-550-01 3-11.5.5; PCSFA-IEDS 4.10).
- **Building Interior (MB-1):** Medium-voltage cables inside buildings must be installed in rigid metal conduit or fully enclosed solid-bottom covered cable tray with minimum 18 inches vertical clearance (6-in tray + 12-in headroom) per UFC 3-520-01 Table 3-1 and PCSFA-IEDS 5.1. A 10-ft keep-out zone must be maintained around SCIF IT-1 walls.

---

## 3. Cost Estimating Basis & Economic Parameters

### 3.1 Estimating Methodology
Estimates are formulated bottom-up in strict compliance with UFC 3-740-05 and RFP Section 01 11 00 Part 3. Direct costs comprise craft labor, construction equipment, permanent materials, and specialized subcontracts. All line items are taken off from the geometric design of each alternative.

### 3.2 Labor Rates & Payroll Burden
Labor hours are derived from contractor labor database PCEC 2026.1, applying production efficiency conversion factors (67/80 for P-405 production units, 0.85 for mechanical cable pullers and bucket trucks). Craft wage rates reflect Department of Labor Davis-Bacon Wage Determination CA20260022 Modification 5 (issued 2026-08-06, which governs under 29 CFR 1.6(c)(2)(ii)(A) as it was published > 10 days prior to sealed bid opening).

Payroll taxes and insurance are applied to base wages only:
- Statutory Taxes: FICA (7.65%) + FUTA (0.60%) + California SUI (3.40%) = 11.65%
- Workers' Compensation Insurance:
  - Code 7538 (Power Line Construction: Lineman, Equipment Specialist, Groundman): 8.74% -> Total Burden = 20.39%
  - Code 6218 (Excavation/Laborers: Group 1, 3, 4, Pump Operator): 7.35% -> Total Burden = 19.00%
  - Code 5190 (Inside Electrical Work: Inside Electrician, Cable Splicer): 4.12% -> Total Burden = 15.77%

#### Table 3-1: Craft Labor Rates Breakdown (CA20260022 Mod 5)
| Craft Position | WD Group | Classification | Base Wage | Fringe Benefit | Burden % | Loaded Hourly Rate |
|:--------------:|:--------:|:--------------:|:---------:|:--------------:|:--------:|:------------------:|
| LINEMAN | ELEC1245-001 | LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER | $70.16 | $24.71 | 20.39% | **$109.18** |
| EQSPEC | ELEC1245-001 | LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST | $53.30 | $22.26 | 20.39% | **$86.43** |
| GROUNDMAN | ELEC1245-001 | LINE CONSTRUCTION: (3) GROUNDMAN | $40.76 | $21.76 | 20.39% | **$70.83** |
| LAB1 | LABO0300-003 | LABORER GROUP 1 | $46.48 | $25.95 | 19.00% | **$81.26** |
| LAB3 | LABO0300-003 | LABORER GROUP 3 | $47.58 | $25.95 | 19.00% | **$82.57** |
| LAB4 | LABO0300-003 | LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER) | $49.13 | $25.95 | 19.00% | **$84.41** |
| PUMPOP | ENGI0012-024 | OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR) | $63.40 | $33.20 | 19.00% | **$108.65** |
| ELECTRICIAN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN | $60.80 | $31.59 | 15.77% | **$101.98** |
| SPLICER_IN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5% ADDITIONAL) | $63.84 | $31.59 | 15.77% | **$105.50** |

### 3.3 Construction Equipment Rates
Owned equipment rates are taken from USACE EP 1110-1-8 (Region VII, Vol 7), adjusted for jobsite bulk fuel prices per Chapter 3 paragraphs 3.9 and 3.10. Jobsite fuel invoice FSI-0826-2207 establishes actual prices of $5.12/gal for unleaded gasoline and $4.38/gal for off-road dyed diesel, compared to Appendix B baselines of $2.49/gal and $2.26/gal, yielding adjustment ratios of 2.0562 (gas) and 1.9381 (diesel). Rented equipment is priced per Westside Equipment Rentals quotation RQ-26-0419.

#### Table 3-2: Equipment Rates Breakdown
| Equipment Code | Description | Source | Hourly Rate |
|:--------------:|:------------|:------:|:-----------:|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET, 22.50' MAX DIGGING DEPTH | EP 1110-1-8 Region VII | **$58.68** |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH, WALK BEHIND, CRAWLER | EP 1110-1-8 Region VII | **$14.61** |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY FRONT END BUCKET, 24" DIP, 14.5' DIGGING DEPTH, 4X2 | EP 1110-1-8 Region VII | **$30.98** |
| C10BO003 | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS IMPACT | EP 1110-1-8 Region VII | **$2.90** |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON, 72' BOOM, 4X4 | EP 1110-1-8 Region VII | **$61.06** |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA, 425 GPM @ 95' HEAD | EP 1110-1-8 Region VII | **$3.85** |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | Rental Quote RQ-26-0419 | **$96.00** |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb with dynamometer | Rental Quote RQ-26-0419 | **$58.50** |
| RQ-TBX | Trench shield (box), 8 ft x 20 ft, steel, with spreaders | Rental Quote RQ-26-0419 | **$7.25** |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | Rental Quote RQ-26-0419 | **$11.80** |

### 3.4 Material Pricing & Escalation Adjustment
Materials are priced per Pacific Electrical Supply quotation Q-2608-114, including recommended waste allowances (3% for MV cable, 5% for conduit/fittings, 8% for concrete, 10% for sand/rock). Nonferrous wire and cable items marked (I) are adjusted from July 2026 base index (482.612) to latest August 2026 index (494.096) per BLS PPI series WPU102603 (adjustment factor 1.0238). Local sales tax of 9.5% is applied to all material totals.

### 3.5 Markups, Escalation & Total Cost Roll-Up
In accordance with RFP Section 01 11 00 paragraph 3.6 and UFC 3-740-05:
- **Job Office Overhead (JOOH):** 9.5% of direct cost.
- **Home Office Overhead (HOOH):** 4.5% of direct cost plus JOOH.
- **Profit (Weighted Guidelines):** 7.95% applied to direct cost + JOOH + HOOH. Determined from weighted factors: Degree of Risk (20% @ 0.08 = 1.60%), Relative Difficulty (15% @ 0.09 = 1.35%), Size of Job for $4.2M programmed amount (15% @ 0.0614 = 0.92%), Period of Performance for 15 months (15% @ 0.0848 = 1.27%), Contractor Investment (5% @ 0.06 = 0.30%), Assistance by Government (5% @ 0.07 = 0.35%), Subcontracting at 30% (25% @ 0.0863 = 2.16%).
- **Performance & Payment Bond:** 1.2819% effective rate, calculated using Sierra Surety Class B schedule applied to the sum of recommended alternatives ($1,226,897.74), including 3% surcharge for 15-month duration.
- **Escalation to Midpoint of Construction:** Factor of 1.019388 (1.9388%), linearly interpolated by day between FY26 and FY27 factors in UFS 3-701-01 Table 4-2 from study date (2026-09-15) to midpoint (2027-08-18).
- **Design Contingency:** 5.0% of contract cost.
- **SIOH (Supervision, Inspection & Overhead):** 5.7% applied to contract cost plus contingency per UFC 3-740-05 Section 13-3.2.
- **Area Cost Factor (ACF):** Set to 1.0 (finding FND-01: ACF prohibited on bottom-up estimates per UFS 3-701-01 4-1.1).

---

## 4. Technical Analysis & Evaluation per Circuit

### 4.1 Circuit C01 — SS-1 Feeder F1 to MB-1 Switchgear Lineup MSG-A

**Circuit Scope & Electrical Design:** Feeder F1 originates at the SS-1 substation F1 stub-out (280, 640) and terminates at the MB-1 electrical room ER-A west wall entry zone (1100, 730). Design current is **640 A** (governed by Protective Device Settings Schedule Rev D row 7, which supersedes the 560 A shown on E-001; see Finding FND-02). Available short-circuit fault current is 16.5 kA symmetrical with a 0.5-second clearing time.
- **Cable Sizing & Ampacity:** Short-circuit capability requires minimum 250 kcmil. Continuous load of 640 A at 100% daily load factor cannot be served by a single set (maximum 1000 kcmil ampacity is 589.8 A in earth ambient 25°C). Therefore, **two parallel sets of 500 kcmil aluminum MV-105 cable** are provided. Ampacity per set at governing condition (Boring B-04 soil rho = 104 C-cm/W, next higher tabulated rho = 120, 25°C ambient, 2 circuits) is **360.4 A**, yielding total feeder ampacity of **720.8 A**, exceeding the 640 A requirement by 12.6%.
- **Conduit & Physical Fill:** 5-inch Type EB-20 PVC ducts (ID = 5.263 in). Three 500 kcmil single conductors (OD = 1.64 in) occupy 29.1% fill (well within the 40% maximum limit). Jam ratio D/d is 3.21, exceeding the 2.8-3.2 critical jam hazard band.
- **Routing & Site Clearances:** Route avoids retained live oak T-201 (20-ft TPZ radius at (520, 655)) by deflecting to northing y = 625 ft (providing 30 ft clearance). Mission Drive (x = 760 to 790) is crossed via an 80-ft horizontal directional bore (4 conduits) from x = 735 to 815 ft, complying with the 50-ft maximum bore extension rule of PCSFA-IEDS 4.3. Manhole C01-MH1 is positioned at (560, 625) and C01-MH2 at (850, 625), both maintaining > 50 ft clearance from road pavement edges and > 200 ft clearance from generator fuel fill FP-1 (UFC 3-550-01 3-11.5.5). The final segment enters ER-A perpendicular to the west wall at (1100, 730).

#### Table 4-1: Conveyance Alternatives Evaluated for C01

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 930 | 717.1 | $61,301.46 | $11,885.85 | $105,362.74 | $14,000.00 | $192,550.05 | **$272,541.19** | **$293.06** | **YES** |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 930 | 645.6 | $55,458.03 | $12,141.89 | $110,411.67 | $14,000.00 | $192,011.59 | **$271,779.03** | **$292.24** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 930 | 324.6 | $28,034.98 | $6,804.45 | $26,910.44 | $14,000.00 | $75,749.87 | **$107,218.67** | **$115.29** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 930 | 457.0 | $39,543.09 | $10,778.54 | $24,035.08 | $90,960.00 | $165,316.71 | **$233,994.29** | **$251.61** | No |
| **OH** | No | PCSFA-IEDS 4.1 (prohibits overhead in industrial area) | 930 | 217.3 | $19,284.80 | $4,780.75 | $36,811.98 | $0.00 | $60,877.53 | **$86,167.90** | **$92.65** | No |

### 4.2 Circuit C02 — SS-1 Feeder F2 to MB-1 Switchgear Lineup MSG-B

**Circuit Scope & Electrical Design:** Feeder F2 originates at SS-1 F2 stub-out (280, 520) and terminates at the MB-1 electrical room ER-B south wall entry zone (1330, 420). Design current is **560 A** at 100% daily load factor. Available fault current is 16.5 kA with a 0.5-second clearing time.
- **Cable Sizing & Ampacity:** Requires minimum 250 kcmil for short-circuit withstand. Two parallel sets of **350 kcmil aluminum MV-105 cable** provide an ampacity of **299.1 A per set** (**598.2 A total**) at 100% LF, rho = 120, 25°C ambient, comfortably exceeding the 560 A design load. Conduit fill in 5-inch EB-20 duct is 24.4% with a safe jam ratio of 3.51.
- **Routing & Site Clearances:** The route jogs south from y = 520 to y = 380 ft to avoid retained oak T-206 (16-ft TPZ at (600, 520)) and to remain completely outside the MB-1 building footprint (south wall at y = 420 ft), complying with UFC 3-550-01 3-11.1.3. Mission Drive is crossed via an 80-ft HDD bore from x = 735 to 815 ft. Three precast manholes (C02-MH1 at (540, 380), C02-MH2 at (860, 380), C02-MH3 at (1180, 380)) provide intermediate pulling access with maximum straight-run spacing of 320 ft (well below the 400-ft UFC limit).

#### Table 4-2: Conveyance Alternatives Evaluated for C02

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,210 | 936.0 | $79,947.41 | $15,536.02 | $139,812.51 | $14,000.00 | $249,295.94 | **$352,861.04** | **$291.62** | **YES** |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 1,210 | 841.0 | $72,182.53 | $15,877.10 | $146,568.63 | $14,000.00 | $248,628.26 | **$351,915.99** | **$290.84** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 1,210 | 409.8 | $35,345.98 | $8,809.80 | $29,061.77 | $14,000.00 | $87,217.55 | **$123,450.37** | **$102.03** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 1,210 | 579.4 | $50,096.13 | $13,930.54 | $25,229.03 | $116,720.00 | $205,975.70 | **$291,544.26** | **$240.95** | No |
| **OH** | No | PCSFA-IEDS 4.1 (prohibits overhead in industrial area) | 1,210 | 244.7 | $21,704.20 | $5,509.39 | $40,119.74 | $0.00 | $67,333.33 | **$95,305.64** | **$78.76** | No |

### 4.3 Circuit C03 — SS-1 Feeder F3 to CUP-1 Switchgear SWG-C1

**Circuit Scope & Electrical Design:** Feeder F3 runs from SS-1 F3 stub-out (240, 700) to CUP-1 switchgear SWG-C1 south wall entry zone (470, 960). Design current is **400 A** at 75% daily load factor. Available fault current is 16.5 kA (0.5 s clearing time).
- **Cable Sizing & Ampacity:** Sized with **one set of 500 kcmil aluminum MV-105 cable**. Governing ampacity at 75% LF (rho = 120, 25°C ambient, 1 circuit) is **461.3 A**, satisfying the 400 A demand. Conduit fill in 5-inch EB-20 is 29.1% (jam ratio 3.21).
- **Routing & Site Clearances:** The route is strategically aligned along x = 275 ft through the open unpaved corridor west of Parking Lot P-1 and east of London plane tree T-202 (16-ft TPZ radius at (245, 820)), maintaining 30 ft clearance from the tree and 25 ft clearance from the parking pavement edge. This route completely eliminates costly asphalt cutting, pavement patching, and heavy rebar encasement required when crossing parking facilities. Precast manhole C03-MH1 is located at (240, 750) near SS-1.

#### Table 4-3: Conveyance Alternatives Evaluated for C03

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 490 | 228.4 | $19,519.70 | $3,482.53 | $41,923.89 | $0.00 | $64,926.12 | **$91,898.40** | **$187.55** | **YES** |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 490 | 211.2 | $18,127.78 | $3,627.74 | $43,309.59 | $0.00 | $65,065.11 | **$92,095.13** | **$187.95** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 490 | 107.6 | $9,297.74 | $1,960.74 | $8,934.27 | $0.00 | $20,192.75 | **$28,581.43** | **$58.33** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 490 | 133.0 | $11,543.13 | $2,931.59 | $7,331.12 | $36,760.00 | $58,565.84 | **$82,895.87** | **$169.18** | No |
| **OH** | No | PCSFA-IEDS 4.1 (prohibits overhead in industrial area) | 490 | 143.3 | $12,716.28 | $3,303.18 | $24,412.31 | $0.00 | $40,431.77 | **$57,228.35** | **$116.79** | No |

### 4.4 Circuit C04 — CUP-1 Feeder CF-2 to Lift Station LS-2 Transformer TX-LS2

**Circuit Scope & Electrical Design:** Feeder CF-2 extends from CUP-1 east wall entry zone (600, 1020) to lift station LS-2 pad-mounted transformer TX-LS2 (1760, 1160). Transformer capacity is 300 kVA, yielding full load current of 12.6 A, protected by breaker 52-CF2 with phase pickup of **60 A** (75% load factor). Available fault current at SWG-C1 is 14.2 kA symmetrical (0.5 s clearing time).
- **Cable Sizing & Ampacity:** Minimum conductor size governed by short-circuit thermal withstand is **250 kcmil** (4/0 AWG rated only 14.1 kA < 14.2 kA). Ampacity of one set of 250 kcmil at 75% LF (rho = 120, 25°C ambient) is **330.5 A**, providing abundant capacity. Conduit fill in 5-inch EB-20 duct is 20.9% (jam ratio 3.79).
- **Routing & Site Clearances:** Starts through the paved CUP-1 yard (x = 600 to 705 ft), constructed as reinforced concrete-encased ductbank per UFGS 33 71 02 3.7.8.1 with asphalt patching. Crosses Mission Drive via an 80-ft HDD bore from x = 735 to 815 ft. Aligns east at y = 1000 ft to clear sycamore tree T-203 (18-ft TPZ at (900, 1030)). Crosses Drainage Channel DC-1 between x = 1530 and 1670 ft via a 140-ft deep directional bore with 120-inch (10-ft) ground cover, complying with Section 404 environmental protection rules (PCSFA-IEDS 4.3, 4.7). The area near DC-1 has shallow groundwater (Boring B-10 at 3.0 ft; Boring B-07 at 4.0 ft) in OSHA Type C granular soil (SM/SP), requiring trench box shoring (TBOX) and active trench dewatering (DEWATER).

#### Table 4-4: Conveyance Alternatives Evaluated for C04

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,215 | 572.2 | $48,943.89 | $9,148.99 | $102,986.56 | $29,704.00 | $190,783.44 | **$270,040.67** | **$222.26** | **YES** |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 1,215 | 476.9 | $40,862.85 | $8,780.41 | $102,103.45 | $29,704.00 | $181,450.71 | **$256,830.84** | **$211.38** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 1,215 | 223.0 | $19,183.71 | $4,602.25 | $14,037.02 | $29,704.00 | $67,526.98 | **$95,579.74** | **$78.67** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 1,215 | 290.8 | $25,140.31 | $6,992.82 | $10,825.90 | $83,160.00 | $126,119.03 | **$178,512.70** | **$146.92** | No |
| **OH** | No | PCSFA-IEDS 4.1 (prohibits overhead in industrial area) | 1,215 | 225.8 | $19,997.80 | $5,514.22 | $33,466.42 | $0.00 | $58,978.44 | **$83,479.87** | **$68.71** | No |

### 4.5 Circuit C05 — MB-1 Interior Feeder A-3 from MSG-A to USS-A1

**Circuit Scope & Electrical Design:** Feeder A-3 is an interior feeder inside Mission Support Facility MB-1, running from medium-voltage switchgear MSG-A (1130, 730) in Room ER-A to unit substation USS-A1 primary section (1440, 640) in Room MR-1. Design current is **200 A** at 40°C indoor ambient temperature. Available fault current at MSG-A bus is 15.8 kA (0.5 s clearing).
- **Conductor Sizing & Raceway:** Conductor short-circuit capability requires minimum 250 kcmil. In air at 40°C ambient, conduit-enclosed ampacity for 350 kcmil is 195 A (insufficient for 200 A pickup). Therefore, **500 kcmil aluminum MV-105 cable** (ampacity **245 A**) is selected. The raceway consists of **5-inch Rigid Metal Conduit (RMC)** with threaded fittings.
- **Admissibility Analysis:** EMT is prohibited for circuits > 600 V by UFGS 26 20 00 paragraph 3.1.6.7. Ladder cable tray (TRAY-LD) is prohibited for interior MV cable by UFC 3-520-01 Table 3-1. Enclosed cable tray (TRAY-EN) requires 18 inches vertical space (6-in tray + 12-in headroom per UFC 3-520-01 Table 3-1 and IEDS 5.1), which exceeds the 14 inches available in Corridor COR-1D (Drawing A-501). Thus, RMC is the **only code-admissible conveyance** for C05.
- **Routing & SCIF Compliance:** RMC runs overhead above suspended ceilings at y = 705 ft, remaining entirely outside the 10-ft keep-out perimeter of SCIF IT-1 (keep-out boundary at y = 710 ft; IEDS 5.1). Firestop seals (FIRESTOP-RMC5) are provided at the 2-hour rated partitions of ER-A and MR-1. Seismic bracing (SEISMIC-BR) is installed every 40 ft transversely and 80 ft longitudinally per UFC 3-301-01 DM-26-04.

#### Table 4-5: Conveyance Alternatives Evaluated for C05

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **RMC** | Yes | PCSFA-IEDS 5.1; UFGS 26 20 00 3.1.6.7 | 400 | 287.0 | $29,303.88 | $1,580.16 | $42,460.14 | $0.00 | $73,344.18 | **$103,813.58** | **$259.53** | **YES** |
| **EMT** | No | UFGS 26 20 00 3.1.6.7 (prohibits EMT > 600 V) | 400 | 231.5 | $23,646.54 | $1,252.85 | $20,469.10 | $0.00 | $45,368.49 | **$64,215.94** | **$160.54** | No |
| **TRAY-EN** | No | PCSFA-IEDS 5.1; A-501 (exceeds COR-1D headroom) | 400 | 303.1 | $30,943.69 | $1,675.03 | $37,670.37 | $0.00 | $70,289.09 | **$99,489.31** | **$248.72** | No |
| **TRAY-LD** | No | UFC 3-520-01 Table 3-1 (prohibits ladder tray for MV) | 400 | 279.1 | $28,496.22 | $1,533.43 | $27,782.52 | $0.00 | $57,812.17 | **$81,829.10** | **$204.57** | No |

### 4.6 Circuit C06 — SS-1 Feeder F4 to Gate House GH-1 Transformer TX-GH1

**Circuit Scope & Electrical Design:** Feeder F4 originates at SS-1 F4 stub-out (180, 480) and serves the 150 kVA pad-mounted transformer TX-GH1 at main gate house GH-1 (1800, 130). Full load current is 6.3 A; protective breaker 52-F4 phase pickup is **40 A** (75% load factor). Available fault current at SS-1 Bus B is 16.5 kA (0.5 s clearing).
- **Conductor & Overhead Sizing:** For underground riser segments, short-circuit withstand requires minimum **250 kcmil** (ampacity 330.5 A >> 40 A). For the overhead line span, **1/0 ACSR Raven** conductor is provided, with an ampacity of **196 A** at 40°C ambient in full sun (rated breaking strength 4,380 lb), easily satisfying the 40 A demand.
- **Admissibility & Recommendation:** Overhead line construction is prohibited inside the congested industrial area (PCSFA-IEDS 4.1). However, C06 transitions south of y = 300 ft into the open utility corridor outside the industrial area boundary. Feeder F4 runs underground via concrete-encased ductbank for 300 ft from SS-1 to riser pole P-01 at (200, 200), runs overhead for 1,570 ft across the site to riser pole P-10 at (1770, 200), and drops underground for 100 ft to the transformer pad. On this route, overhead spans represent 80% of the run length, making **OH admissible as the predominant conveyance** per RFP 1.4. Because OH avoids over 1,500 ft of heavy trenching, concrete encasement, manholes, and a directional bore under Channel DC-1, it reduces total project cost by **$223,173** compared to CEDB ($129,512 vs $352,685), making **OH the recommended conveyance**.
- **Pole Line Design:** 10 Class 3 wood poles: eight 45-ft poles and two 50-ft poles spanning Mission Drive (providing required roadway clearance per IEDS 4.9). Maximum span is 240 ft (well below the 300-ft limit for 1/0 ACSR). The span across Channel DC-1 (P-08 to P-09) is 160 ft, positioned completely outside the 25-ft top-of-bank channel buffers. Riser poles P-01 and P-10 are equipped with down guys and screw anchors (GUY-ASSY) and riser termination assemblies (RISER-ASSY).

#### Table 4-6: Conveyance Alternatives Evaluated for C06

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 1,970 | 817.9 | $69,674.39 | $13,355.03 | $150,438.09 | $15,704.00 | $249,171.51 | **$352,684.92** | **$179.03** | No |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 1,970 | 753.5 | $64,470.51 | $13,895.90 | $155,640.17 | $15,704.00 | $249,710.58 | **$353,447.94** | **$179.42** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 1,970 | 353.3 | $30,331.52 | $7,445.35 | $22,066.52 | $15,704.00 | $75,547.39 | **$106,932.07** | **$54.28** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 1,970 | 453.6 | $39,180.28 | $11,186.32 | $16,273.95 | $131,480.00 | $198,120.55 | **$280,425.84** | **$142.35** | No |
| **OH** | Yes | PCSFA-IEDS 4.1; UFC 3-550-01 3-11 (permitted outside industrial area) | 1,970 | 360.8 | $31,417.42 | $7,915.85 | $52,166.54 | $0.00 | $91,499.81 | **$129,511.61** | **$65.74** | **YES** |

### 4.7 Circuit C07 — CUP-1 Feeder CF-1 to Warehouse W-3 Transformer TX-W3

**Circuit Scope & Electrical Design:** Feeder CF-1 extends from CUP-1 switchgear SWG-C1 north wall entry zone (470, 1060) to warehouse W-3 pad-mounted transformer TX-W3 (1030, 1180). Transformer capacity is 1,500 kVA (62.8 A full load), protected by breaker 52-CF1 with phase pickup of **120 A** (75% load factor). Available fault current at SWG-C1 is 14.2 kA (0.5 s clearing).
- **Cable Sizing & Ampacity:** Requires minimum **250 kcmil** for short-circuit withstand (rated 16.6 kA >= 14.2 kA). Ampacity of one set of 250 kcmil at 75% LF (rho = 120, 25°C ambient) is **330.5 A**, exceeding the 120 A design load. Conduit fill in 5-inch EB-20 is 20.9% (jam ratio 3.79).
- **Routing, Rail Crossing & Clearances:** Both CUP-1 and W-3 lie inside the congested industrial area, and W-3 is flanked by the gantry crane operating area, excluding overhead distribution (PCSFA-IEDS 4.1). Active rail spur RR-SPUR-2 is crossed between y = 1085 and 1115 ft via Jack-and-Bore (JB) using two 5-inch RGS conduits (crossing length = 30 ft <= 50 ft; top of conduit 42 in below finished grade / 50 in below top of rail per PCSFA-IEDS 4.5). Mission Drive is crossed via an 80-ft HDD bore from x = 735 to 815 ft. Retained live oak T-204 (12-ft TPZ at (650, 1118)) is cleared by 17 ft at northing y = 1135 ft. Manholes C07-MH1 (470, 1135) and C07-MH2 (860, 1135) provide pulling access.

#### Table 4-7: Conveyance Alternatives Evaluated for C07

| Conveyance Type | Admissible | Governing Clause / Exclusion Reason | Route Length (ft) | Labor MH | Labor Cost | Equipment Cost | Material Cost | Subcontract Cost | Direct Cost | Total Project Cost | Cost / LF | Recommended |
|:---------------:|:----------:|:------------------------------------|:-----------------:|:--------:|:----------:|:--------------:|:-------------:|:----------------:|:-----------:|:------------------:|:---------:|:-----------:|
| **CEDB** | Yes | PCSFA-IEDS 4.2; UFC 3-550-01 3-11.2.1 | 680 | 309.4 | $26,446.50 | $4,974.58 | $67,131.93 | $32,290.00 | $130,843.01 | **$185,199.17** | **$272.35** | **YES** |
| **UEDB** | No | PCSFA-IEDS 4.2 (prohibits unencased for primary) | 680 | 289.7 | $24,852.63 | $5,143.44 | $68,788.26 | $32,290.00 | $131,074.33 | **$185,526.59** | **$272.83** | No |
| **DBC** | No | PCSFA-IEDS 4.2 (prohibits direct-burial for primary) | 680 | 135.5 | $11,688.71 | $2,633.07 | $12,963.28 | $32,290.00 | $59,575.06 | **$84,324.35** | **$124.01** | No |
| **HDD** | No | PCSFA-IEDS 4.3; UFC 3-550-01 3-11.4.1 (prohibits HDD for entire run) | 680 | 175.0 | $15,159.20 | $4,011.64 | $6,952.85 | $48,920.00 | $75,043.69 | **$106,219.12** | **$156.20** | No |
| **OH** | No | PCSFA-IEDS 4.1 (prohibits overhead in industrial area) | 680 | 159.5 | $14,142.65 | $3,715.78 | $24,485.62 | $0.00 | $42,344.05 | **$59,935.05** | **$88.14** | No |

---

## 5. Cable Pulling & Structural Calculations

Pulling calculations were performed in accordance with TD-15AL-133 Section 4.7 and approved submittal SUB-33 71 02-07 for all cable pulls of the recommended designs. Tension was computed section-by-section assuming an initial reel feed-in tension of 100 lb, with dynamic coefficients of friction of 0.35 for PVC duct, 0.30 for HDPE bore conduit, and 0.40 for rigid steel conduit. Sidewall bearing pressures (SWBP) were evaluated at all horizontal long-sweep bends (25-ft radius) and vertical equipment riser sweeps (3-ft radius) using the cradled cable configuration equations.

In all cases, cable tensions remain well below allowable pulling limits (6,000 lb for 500 kcmil, 4,200 lb for 350 kcmil, 3,000 lb for 250 kcmil), and sidewall bearing pressures remain strictly below the approved project-specific limit of **600 lb/ft**.

### Table 5-1: Cable Pulling Calculations Summary

| Item ID | Pull ID | From Structure | To Structure | Pull Length (ft) | Max Pulling Tension (lb) | Tension Limit (lb) | Max SWBP (lb/ft) | SWBP Limit (lb/ft) | Jam Ratio (D/d) | Conduit Fill % |
|:-------:|:-------:|:--------------:|:------------:|:----------------:|:------------------------:|:------------------:|:----------------:|:------------------:|:---------------:|:--------------:|
| C01 | C01-P1 | START | C01-MH1 | 285.0 | 822 | 6,000 | 41.0 | 600 | 3.21 | 29.1% |
| C01 | C01-P2 | C01-MH1 | C01-MH2 | 290.0 | 651 | 6,000 | 0.0 | — | 3.21 | 29.1% |
| C01 | C01-P3 | C01-MH2 | END | 355.0 | 1,315 | 6,000 | 41.0 | 600 | 3.21 | 29.1% |
| C02 | C02-P1 | START | C02-MH1 | 380.0 | 980 | 4,200 | 52.0 | 600 | 3.51 | 24.4% |
| C02 | C02-P2 | C02-MH1 | C02-MH2 | 320.0 | 575 | 4,200 | 0.0 | — | 3.51 | 24.4% |
| C02 | C02-P3 | C02-MH2 | C02-MH3 | 320.0 | 575 | 4,200 | 0.0 | — | 3.51 | 24.4% |
| C02 | C02-P4 | C02-MH3 | END | 190.0 | 480 | 4,200 | 48.0 | 600 | 3.51 | 24.4% |
| C03 | C03-P1 | START | C03-MH1 | 50.0 | 195 | 6,000 | 0.0 | — | 3.21 | 29.1% |
| C03 | C03-P2 | C03-MH1 | END | 440.0 | 940 | 6,000 | 65.0 | 600 | 3.21 | 29.1% |
| C04 | C04-P1 | START | C04-MH1 | 280.0 | 540 | 3,000 | 0.0 | — | 3.79 | 20.9% |
| C04 | C04-P2 | C04-MH1 | C04-MH2 | 340.0 | 530 | 3,000 | 0.0 | — | 3.79 | 20.9% |
| C04 | C04-P3 | C04-MH2 | C04-MH3 | 365.0 | 610 | 3,000 | 35.0 | 600 | 3.79 | 20.9% |
| C04 | C04-P4 | C04-MH3 | END | 230.0 | 460 | 3,000 | 0.0 | — | 3.79 | 20.9% |
| C05 | C05-P1 | START | PBOX-01 | 32.0 | 160 | 6,000 | 45.0 | 600 | 3.08 | 31.7% |
| C05 | C05-P2 | PBOX-01 | END | 382.0 | 890 | 6,000 | 85.0 | 600 | 3.08 | 31.7% |
| C06 | C06-P1 | START | P-01 | 300.0 | 560 | 3,000 | 42.0 | 600 | 3.79 | 20.9% |
| C06 | C06-P2 | P-01 | P-10 | 1,570.0 | 850 | 3,000 | 0.0 | — | — | — |
| C06 | C06-P3 | P-10 | END | 100.0 | 245 | 3,000 | 38.0 | 600 | 3.79 | 20.9% |
| C07 | C07-P1 | START | C07-MH1 | 75.0 | 220 | 3,000 | 0.0 | — | 3.79 | 20.9% |
| C07 | C07-P2 | C07-MH1 | C07-MH2 | 390.0 | 595 | 3,000 | 0.0 | — | 3.79 | 20.9% |
| C07 | C07-P3 | C07-MH2 | END | 215.0 | 420 | 3,000 | 40.0 | 600 | 3.79 | 20.9% |

---

## 6. Register of Applied Criteria & Requirements

The following table records the governing criteria, standards, clauses, and values applied throughout the conveyance study:

| Req ID | Document | Clause | Requirement Summary | Applied Value / Design Standard | Applies To |
|:------:|:---------|:------:|:--------------------|:--------------------------------|:-----------|
| REQ-01 | PCSFA-IEDS Rev 3 | 2.1 | Primary distribution 13.8 kV, resistance grounded; cable single-conductor MV-105 XLPE 133% insulation, copper tape shield, aluminum conductor; min size 1/0 AWG; 3 single conductors per duct | 13.8 kV 3-wire, MV-105 XLPE 133% Al | All items |
| REQ-02 | PCSFA-IEDS Rev 3 | 2.2 | Feeder ampacity (ampacity per set x sets) shall not be less than phase pickup setting of feeder protective device | Feeder ampacity >= pickup | All items |
| REQ-03 | PCSFA-IEDS Rev 3 | 2.3 | Load factor for ampacity: 100% for mission feeders F1 (C01) and F2 (C02); 75% for all other feeders | 100% for C01, C02; 75% for C03, C04, C06, C07 | Site items |
| REQ-04 | PCSFA-IEDS Rev 3 | 2.4 | Short-circuit withstand: cable short-circuit capability for backup clearing time shall not be less than available fault current | Capability >= Available fault current | All items |
| REQ-05 | PCSFA-IEDS Rev 3 | 4.1 | Conveyance selection: overhead distribution prohibited inside industrial area delineated on C-101 and within W-3 dock crane area; permitted outside with underground risers | Overhead prohibited in industrial area | All site items |
| REQ-06 | PCSFA-IEDS Rev 3 | 4.2 | Primary distribution between structures/equipment shall be concrete-encased ductbanks; direct-buried cable and unencased conduit not permitted | CEDB required; UEDB & DBC prohibited | All site items |
| REQ-07 | PCSFA-IEDS Rev 3 | 4.3 | Existing pavement: Perimeter Rd, Mission Dr, MB-1 access dr: do not open-cut, cross by bore; Parking P-1 and CUP yard: may saw-cut and patch with reinforced encasement extending 5 ft; Channel DC-1: no open cut | No open cut for major roads/channel; reinforced under P-1/CUP yard | C01, C02, C04, C07 |
| REQ-08 | PCSFA-IEDS Rev 3 | 4.4 | Redundancy: SS-1 bus A (F1, F3) and bus B (F2, F4) feeders shall not share ductbanks/structures and maintain >= 20 ft separation except within 50 ft of fence/walls | Bus A & B >= 20 ft separation; no sharing | C01, C02, C03, C06 |
| REQ-09 | PCSFA-IEDS Rev 3 | 4.5 | Active rail spur RR-SPUR-2: cross by jacked RGS conduit (length <= 50 ft) or jack-and-sleeve; top of conduit >= 50 in below top of rail | Jack & Bore RGS <= 50 ft; depth >= 50 in below top of rail | C07 |
| REQ-10 | PCSFA-IEDS Rev 3 | 4.6 | Ampacity basis: manufacturer tables, nearest boring soil rho, 25 C earth ambient, lowest ampacity along route governs; bores/jacked <= 25% of run excluded from governing condition | Nearest boring rho, 25 C earth ambient, 40 C air | All items |
| REQ-11 | PCSFA-IEDS Rev 3 | 4.7 | Directional bores: HDPE SDR 11, conduit fill <= 30%, cover under pavement 48 in, elsewhere 120 in | HDPE SDR 11, max 30% fill, 48" or 120" cover | C01, C02, C04, C07 |
| REQ-12 | PCSFA-IEDS Rev 3 | 4.8 | Ductbanks: EB-20 PVC, min 5 in duct, 3 in spacing, 3 in concrete cover, spare conduits >= 1/3 of bank (min 1 spare), 4/0 AWG bare copper ground wire | EB-20 5", 3" space/cover, >= 33.3% spares, 4/0 Cu ground | All site items |
| REQ-13 | PCSFA-IEDS Rev 3 | 4.9 | Overhead lines: max span (1/0 ACSR 300 ft), wood Class 3 poles 45 ft (50 ft at road crossings), guys on deflections > 5 deg, dead-ends on > 60 deg, riser poles dead-end with 1 guy; poles >= 25 ft from buildings, >= 6 ft from road edge, clear of rail and channel buffer | Poles 45/50 ft, road spans 50 ft, clearances >= 25 ft bldg, >= 6 ft road | C06 |
| REQ-14 | PCSFA-IEDS Rev 3 | 4.10 | Underground structures: UFC 3-550-01 3-11.5/3-11.6, Air Force distances (>= 50 ft from pavement edge, >= 200 ft from fueling point), not in pavement; max spacing 400 ft on straight runs; long-sweep bends 25 ft radius | MH >= 50 ft pavement, >= 200 ft fueling; max 400 ft straight run | All site items |
| REQ-15 | SUB-33 71 02-07 | Item 1 & 2 | Approved cable submittal: maximum pulling tension 0.006 lb/cmil of two conductors (max 10,000 lb); maximum sidewall bearing pressure 600 lb/ft (governs over 1,000 lb/ft catalogue value) | Tension <= 0.006 lb/cmil (2 cond); SWBP <= 600 lb/ft | All items |
| REQ-16 | PCSFA-IEDS Rev 3 | 4.12 | Excavations: 29 CFR 1926 Subpart P, nearest boring log, least stable layer; granular soils and below groundwater are Type C; excavations >= 5 ft require sloping or trench shield; dewater excavations below groundwater | OSHA Subpart P, sloping / trench box >= 5 ft; dewater below GW | All site items |
| REQ-17 | PCSFA-IEDS Rev 3 | 4.14 | Retained trees have tree protection zone radius 1 ft/inch DBH; no trench/manhole/pole within TPZ; bore beneath TPZ with >= 48 in cover | TPZ radius = 1 ft / in DBH; no excavation in TPZ | All site items |
| REQ-18 | PCSFA-IEDS Rev 3 | 5.1 | Building conveyances: UFC 3-520-01 Table 3-1, UFGS 26 20 00 3.1.6/3.1.8; vertical space required: tray 6 in + 12 in headroom = 18 in, rigid conduit 6 in; 10 ft keep-out around SCIF IT-1; 7 ft rises with 90 deg elbows | Tray 18" space, RMC 6"; 10 ft SCIF keep-out; 7 ft rises | C05 |
| REQ-19 | UFGS 26 20 00 | 3.1.6.7 | Conduit for circuits rated > 600 V inside buildings shall be rigid metal conduit (RMC) or IMC only (prohibits EMT) | RMC or IMC only for MV inside buildings | C05 |
| REQ-20 | UFC 3-520-01 | Table 3-1 | Interior medium-voltage cable must be installed in raceway or fully enclosed cable tray (prohibits open ladder tray) | Fully enclosed raceway or tray for interior MV | C05 |
| REQ-21 | UFS 3-701-01 | 4-1.1 | MILCON Area Cost Factors shall not be applied to detailed quantity take-offs or bottom-up estimates priced with local rates | ACF = 1.0 (not applied to bottom-up estimate) | All items |
| REQ-22 | 29 CFR 1.6 | (c)(2)(ii)(A) | General wage determination revision published at least 10 calendar days before sealed bid opening is effective for the contract | WD CA20260022 Mod 5 governs over Mod 2 | All items |

---

## 7. Register of Document Defects & Corrections (Findings)

In accordance with RFP Section 01 11 00 paragraph 1.6, the contractor has reviewed the Government-furnished documents and identified the following errors, conflicts, and inconsistencies, together with the corrective actions implemented in this study:

### FND-01: Government Estimate Template PCSFA FY26
- **Document Location:** Summary Sheet, Lines 2-3 (Rows 5-6)
- **Identified Defect:** The Government Estimate Template applies an Area Cost Factor (ACF) of 1.16 to the bottom-up direct cost. This directly contradicts UFS 3-701-01 Section 4-1.1, which strictly prohibits using MILCON ACFs on detailed quantity take-offs / bottom-up estimates priced with local quotes, wage determinations, and regional equipment schedules.
- **Correction Applied:** Area Cost Factor applied was set to 1.0 (no location adjustment factor applied) in accordance with RFP Section 01 11 00 paragraph 3.1 and UFS 3-701-01 paragraph 4-1.1.

### FND-02: Drawing E-001 (One-Line Diagram Rev B) vs Protective Device Settings Schedule Rev D
- **Document Location:** Drawing E-001 Breaker 52-F1 vs Schedule Rev D row 7
- **Identified Defect:** Drawing E-001 indicates feeder 52-F1 51P pickup of 560 A, whereas the current Protective Device Settings Schedule Rev D indicates a phase pickup setting of 640 A (increased for MB-1 Phase 2 load).
- **Correction Applied:** Used 640 A design current for feeder F1 (C01) in accordance with PCSFA-IEDS Rev 3 paragraph 1.3 Order of Precedence (clause 4: protective device settings schedule governs over device ratings shown on one-line diagrams).

### FND-03: Solicitation Attachment J-3 vs DOL WHD Wage Determination Publication
- **Document Location:** Solicitation Attachment J-3 (CA20260022 Mod 2) vs 50_cost/wage_determinations/CA20260022_Mod5_2026-08-06.txt
- **Identified Defect:** Attachment J-3 contains Wage Determination CA20260022 Modification 2 (published 2026-01-30). However, the Department of Labor published Modification 5 on 2026-08-06, which is 63 calendar days prior to the sealed bid opening date of 2026-10-08.
- **Correction Applied:** Applied Modification 5 in accordance with RFP Section 01 11 00 paragraph 2.1 and 29 CFR 1.6(c)(2)(ii)(A), which mandates incorporation of wage determination modifications issued at least 10 calendar days before sealed bid opening.

### FND-04: TD-15AL-133 Cable Data Sheet Rev 3 vs Approved Cable Submittal SUB-33 71 02-07
- **Document Location:** TD-15AL-133 Section 4.2 vs Submittal Item 2 (Letter dated 2026-08-14)
- **Identified Defect:** Manufacturer general catalogue data sheet TD-15AL-133 Section 4.2 states a maximum sidewall bearing pressure of 1,000 lb/ft. The approved project submittal letter sets a strict project-specific limit of 600 lb/ft of bend radius for tape-shielded construction furnished to this project.
- **Correction Applied:** Applied the 600 lb/ft sidewall bearing pressure limit per PCSFA-IEDS Rev 3 paragraph 1.3 Order of Precedence (clause 3: approved project submittals govern over manufacturers general catalogue data).

### FND-05: Geotechnical Report GEO-24-0117 Table 2 vs Boring Logs B-07 / B-10 and 29 CFR 1926 Subpart P
- **Document Location:** GEO-24-0117 Section 8, Table 2 (Summary of Soil Classification)
- **Identified Defect:** Table 2 lists OSHA soil type as Type B for Borings B-7 and B-10. However, the boring logs and laboratory data show poorly graded sand (SP) from 3 to 9 ft at B-7 with perched groundwater at 4.0 ft, and silty sand (SM) from 2 to 12 ft at B-10 with groundwater at 3.0 ft. Under 29 CFR 1926 Subpart P Appendix A and IEDS 4.12, granular soils and soils below groundwater table must be classified as Type C.
- **Correction Applied:** Classified soils at B-7 and B-10 as OSHA Type C with maximum allowable slope of 1.5H:1V per 29 CFR 1926 Subpart P Appendix B and IEDS 1.3 (clause 6: boring logs and laboratory results govern over summary tables of geotechnical reports).

---
**End of Conveyance Study Report**