# Building B - seismic diaphragm and shear wall design basis

Design format: LRFD

## 1. Seismic basis

Building B is a one-storey data hall box measuring 240 ft-0 in (E-W, X-axis) by 180 ft-0 in (N-S, Y-axis) in plan, located in Lewis and Clark County, Montana (latitude 46.6832, longitude -111.9756). Top of roof deck is at EL +28'-0", and the exterior 8 in solid normal-weight precast concrete wall panels cantilever above the deck to top of parapet at EL +31'-0".

* **Risk Category:** Risk Category III per Owner's Basis of Design (OBD-CDDC-B Rev 4 Section 1.4) and Structural Design Criteria (SDC-02 Rev 2 Section 2). Building B houses the Lewis and Clark County consolidated 911 emergency communications tenant on its east side, including the emergency dispatch floor and radio equipment room, which is an occupancy required for emergency response. The seismic importance factor is $I_e = 1.25$ (ASCE/SEI 7-22 Section 11.5.1, Table 1.5-2).
* **Site Classification:** Site Class D per Geotechnical Investigation GEO-2026-071 Section 4, based on boring B-204 downhole shear wave velocity survey yielding $V_{s,100} = 905\text{ ft/s}$. This supersedes the 2019 report GEO-2019-118 prepared under ASCE 7-16 for the adjacent Parcel 4B.
* **Ground Motion Acceleration Parameters:** Design spectral response accelerations from USGS Seismic Design Web Service for ASCE 7-22 Risk Category III Site Class D are $S_{DS} = 0.44\text{g}$ and $S_{D1} = 0.24\text{g}$ ($S_s = 0.49\text{g}$, $S_1 = 0.13\text{g}$, $T_L = 6.0\text{ s}$).
* **Seismic Design Category:** SDC D per ASCE/SEI 7-22 Section 11.6, governed by Table 11.6-2 where $S_{D1} = 0.24\text{g} \ge 0.20\text{g}$ for Risk Category III.
* **Effective Seismic Weight:**
  * Net roof dead load: $39,200\text{ sq ft} \times 20\text{ psf} = 784.0\text{ kips}$ (openings RO-1 $60'\times 40'$ and RO-2 $80'\times 20'$ deducted).
  * Mechanical RTU equipment (Phase 1): $45.0\text{ kips}$ operating weight across 6 units per M-601 Rev 3.
  * Exterior walls tributary to roof: $840\text{ lin ft} \times 1,716.07\text{ plf} = 1,441.50\text{ kips}$, accounting for cantilever lever action ($H_{trib} = H^2 / (2h) = 31^2 / (2\times 28) = 17.16\text{ ft}$, FEMA P-2192-V1 Section 7.6.1 Step 1).
  * Total effective seismic weight: $W_{base} = 2,270.50\text{ kips}$.
  * Future mass case incorporates Phase 2 reserved units RTU-7F and RTU-8F ($16.0\text{ kips}$), giving $W_{future} = 2,286.50\text{ kips}$.
* **Seismic Response Coefficient and Base Shear:**
  * Fundamental period: $T_a = C_t h_n^x = 0.020 \times (28.0)^{0.75} = 0.244\text{ s} < T_s = 0.548\text{ s}$.
  * Seismic response coefficient: $C_s = S_{DS} / (R / I_e) = 0.44 / (4.0 / 1.25) = 0.1375$ (governed by Eq. 12.8-2; exceeds minimum $0.044 S_{DS} I_e = 0.0242$).
  * Seismic base shear: $V = C_s W = 0.1375 \times 2,270.50 = 312.19\text{ kips}$ at strength level ($F_x = V$ at roof level).

## 2. Seismic force-resisting system

The selected seismic force-resisting system is **Intermediate Precast Shear Walls** (bearing wall system), permitted in Seismic Design Category D by ASCE/SEI 7-22 Table 12.2-1 / UFC 3-301-01 Table 3-1 Item A.6:
* Response modification coefficient: $R = 4.0$
* Deflection amplification factor: $C_d = 4.0$
* Tabulated overstrength factor: $\Omega_0 = 2.5$
* Collector overstrength factor: $\Omega_0 = 2.0$, applying the $0.5$ reduction permitted by UFC 3-301-01 Table 3-1 footnote b / ASCE 7-22 Table 12.2-1 footnote b for flexible diaphragm structures (bare untopped steel deck on concrete shear walls under Section 12.3.1.1).
* Structural height limit: $h_n \le 40\text{ ft}$ in SDC D. Building B has $h_n = 28\text{ ft}$ to roof deck ($31\text{ ft}$ to top of parapet), fully compliant with the $40\text{ ft}$ limitation.

**Why this is the cost-efficient choice:**
Under SDC D, Ordinary Precast Shear Walls are strictly prohibited (marked "NP" in Table 12.2-1 / Table 3-1 Item A.7). The only other permitted precast system is Special Reinforced Concrete Shear Walls ($R = 5, \Omega_0 = 2.5, C_d = 5$). However, Special Precast carries an exorbitant SFRS detailing premium of $4,120 per panel (vs $1,850 for intermediate precast) and requires ductile qualified connectors (RPC-60D under ACI 318-19 Section 18.5.2 / ITG-5.2) at $1,240 each (vs $0 for isolated panel piers or $385 for RPC-24). For the 81 erected panels, Special Precast would add over $183,000 in detailing premiums alone, exceeding the capital cap of $395,000. Intermediate precast shear walls provide full code compliance within the 40 ft height limit at minimum cost, achieving $104,694 in budget savings.

## 3. As-built geometry

The delegated lateral design is based on the as-built erected geometry established by the 7 August 2026 interior scan (ScanB_2026-08-07), the survey control report CDDC-SV-2026-041, the erection log ERL-2026-08, and RFI-041. All conflicts between project documents were resolved as follows:

1. **Risk Category Conflict:** The architectural cover sheet schematic code block listed Risk Category II. SDC-02 Rev 2 Section 2 and OBD-CDDC-B Rev 4 Section 1.4 formally established Risk Category III ($I_e = 1.25$) due to the Lewis and Clark County 911 emergency communications tenant. The architectural cover sheet is superseded.
2. **Geotechnical Site Class Conflict:** The 2019 report GEO-2019-118 indicated Site Class C for adjacent Parcel 4B under ASCE 7-16. GEO-2026-071 Section 4 performed a downhole shear wave survey in boring B-204 on the Building B parcel, measuring $V_{s,100} = 905\text{ ft/s}$ (Site Class D under ASCE 7-22 Chapter 20), explicitly superseding all prior classifications for Building B.
3. **South Wall Dock Door D-3 and Pier Lengths:** PC-101 Rev 2 detailed D-3 at 14'-0" clear and the D-4/D-5 pier at 16'-0". ERL-2026-08 and RFI-041 confirm D-3 was erected at 15'-6" clear (X = 78.0 to 93.5 ft), shifting panel S-12 and all panels east by 1'-6", closing the pier between D-4 and D-5 to 14'-6" (X = 123.5 to 138.0 ft). The EOR accepted this as the permanent design geometry in RFI-041.
4. **North Wall Louver L-2 Recast:** PC-101 Rev 2 detailed L-2 at 12'-0" (X = 156 to 168 ft). Panel N-12 was recast to shop ticket Rev B (PCS-014), widening L-2 to 16'-0" and shifting it 2 ft west to X = 154.0 to 170.0 ft. The design incorporates this 16 ft opening.
5. **West Wall Electrical Yard Opening EY-1:** S-201 and PC-101 detailed EY-1 at 40'-0" (Y = 66 to 106 ft). Per field change FC-018 and RFI-041, EY-1 was widened on site to 44'-0" (Y = 66.0 to 110.0 ft) for the generator bus duct, and panel W-15 was omitted. The as-built pier W-P3 is 70.0 ft long (Y = 110.0 to 180.0 ft).
6. **Diaphragm Flexibility Idealization:** While ASCE 7-22 Section 12.3.1.1 permits untopped steel deck on concrete shear walls to be idealized as flexible, peer review PR-07 Comment 7 noted that significant plan cutouts (60'x40' mechanical well and 80'x20' skylight) and severe wall opening asymmetry create substantial torsional eccentricity that flexible tributary distribution does not bound. The design forces envelope flexible, rigid, and semi-rigid distributions per SDC-02 Section 10 and DAP-2 Rev 1.
7. **Collector Overstrength Factor:** ASCE 7-22 Table 12.2-1 lists $\Omega_0 = 2.5$. Footnote b permits a 0.5 reduction for structures with flexible diaphragms. SDC-02 Rev 2 Section 4 adopts $\Omega_0 = 2.0$ for all collector and drag strut lines.
8. **Diaphragm Design Method:** SDC-02 Rev 2 Section 5 bars Sections 12.10.3 and 12.10.4, specifying the traditional provisions of Sections 12.10.1 and 12.10.2 for bare steel deck.

## 4. Analysis

Analysis strictly follows the two-stage protocol of DAP-2 Rev 1:
* **Stage A (Wall Segments):** Each precast panel is modelled as a cantilever fixed at the foundation with lateral displacement $u$, vertical slip $v$, and rotation $\theta$ at the roof deck level ($h = 28.0\text{ ft}$). Flexural rigidity uses cracked inertia $I_{cr} = 0.50 I_g$ (ACI 318-19 Table 6.6.3.1.1(a)), and shear flexibility uses $A_v = 5/6 A_g$ with $G_c = E_c / 2.4$ and $E_c = 57,000\sqrt{f'_c} = 4,415.2\text{ ksi}$ ($f'_c = 6,000\text{ psi}$). Spandrels over partial-height openings (louvers L-1, L-2, L-3) keep their length and factor flexural and shear rigidities by the solid fraction ($18/28 = 0.643$). Adjacent panels are connected by vertical shear springs at joints. For isolated panel piers (JC0), $k_{joint} = 0$, yielding isolated cantilever behavior matching DAP-2 Appendix A ($k_{seg} = 769.2\text{ kip/in}$ for four 10 ft panels).
* **Stage B (Roof Diaphragm):** Plane-stress membrane mesh on a 10 ft square grid ($24 \times 18$ grid, 475 nodes, 392 active Q4 elements). Membrane constitutive matrix $D = \text{diag}(A', A', G')$ with $A' = 1,740\text{ kip/in}$ (smeared bare deck axial stiffness) and $G'$ from BDS-2026-DT Table 4. Roof openings RO-1 and RO-2 elements are removed. Chords, collectors, and drag struts are modelled as 2-node bar elements ($E = 29,000\text{ ksi}$). Wall segments act as in-plane springs to ground distributed over boundary nodes in proportion to tributary length.
* **Loads & Accidental Torsion:** Inertial diaphragm loads apply $C_s = 0.1375$ times the tributary mass: net roof DL ($784.0\text{ k}$), RTUs at coordinates ($45.0\text{ k}$), and perpendicular wall tributary weights ($617.79\text{ k}$ for E-W loading, $823.71\text{ k}$ for N-S loading). Parallel walls carry their own inertia directly into their foundations. Accidental torsion applies plan moment $M_{acc} = \pm 0.05 B A_x F_{tot}$ distributed as a mass-proportional rotational force field about the center of mass. Torsional amplification $A_x = [\delta_{max} / (1.2\delta_{avg})]^2$ is evaluated from the rigid diaphragm model ($A_x = 1.000$ for final stage cases; $A_x = 1.354$ for S11 and $A_x = 2.778$ for S12 due to deck unfastened east of X = 180 ft).
* **Envelope (DAP-2 Section 6.3):** Every design demand (zone shear, wall line force, chord/collector axial force) is taken as the maximum of flexible, rigid ($10^7 D$), and semi-rigid models. Orthogonal combinations (S05, S06, S09, S10) combine $100\% + 30\%$ orthogonal demands per Section 6.4.

## 5. Diaphragm and wall forces

* **Diaphragm Design Forces (ASCE 7-22 Section 12.10.1.1):**
  * **E-W Loading (X-dir):** Tributary weight $w_{px} = 1,446.79\text{ kips}$, $F_{px} = C_s w_{px} = 198.93\text{ kips}$, diaphragm span $L = 180.0\text{ ft}$, distributed diaphragm load $w_{px} = 1,105.18\text{ plf}$.
  * **N-S Loading (Y-dir):** Tributary weight $w_{px} = 1,652.71\text{ kips}$, $F_{px} = C_s w_{px} = 227.25\text{ kips}$, diaphragm span $L = 240.0\text{ ft}$, distributed diaphragm load $w_{px} = 946.87\text{ plf}$.
* **Governing Wall Line Shears (kips):**
  * **Wall Line S:** Maximum shear force $F_x = 103.73\text{ kips}$ (governed by S09, future 100/30).
  * **Wall Line N:** Maximum shear force $F_x = 121.87\text{ kips}$ (governed by S09, future 100/30; $117.29\text{ kips}$ in S02).
  * **Wall Line W:** Maximum shear force $F_x = 119.60\text{ kips}$ (governed by S10, future 100/30; $117.06\text{ kips}$ in S04).
  * **Wall Line E:** Maximum shear force $F_x = 125.18\text{ kips}$ (governed by S08, future mass Y +1).
* **Deck Attachment Zones:**
  * Zone design shears represent the maximum section mean across each 60'x60' zone per DAP-2 Section 6.1.
  * Z1 ($935.1\text{ plf}$) $\rightarrow$ Pattern P5 ($\phi S_n = 1,101.0\text{ plf}$, util $84.9\%$)
  * Z2 ($530.5\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $80.0\%$)
  * Z3 ($510.2\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $77.0\%$)
  * Z4 ($761.7\text{ plf}$) $\rightarrow$ Pattern P4 ($\phi S_n = 852.0\text{ plf}$, util $89.4\%$)
  * Z5 ($590.3\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $89.0\%$)
  * Z6 ($262.3\text{ plf}$) $\rightarrow$ Pattern P2 ($\phi S_n = 474.0\text{ plf}$, util $55.3\%$; P2 chosen to control S12 deflection to $3.68\text{ in}$)
  * Z7 ($347.4\text{ plf}$) $\rightarrow$ Pattern P2 ($\phi S_n = 474.0\text{ plf}$, util $73.3\%$)
  * Z8 ($591.8\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $89.3\%$)
  * Z9 ($723.7\text{ plf}$) $\rightarrow$ Pattern P4 ($\phi S_n = 852.0\text{ plf}$, util $84.9\%$)
  * Z10 ($480.4\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $72.5\%$)
  * Z11 ($525.6\text{ plf}$) $\rightarrow$ Pattern P3 ($\phi S_n = 663.0\text{ plf}$, util $79.3\%$)
  * Z12 ($768.7\text{ plf}$) $\rightarrow$ Pattern P4 ($\phi S_n = 852.0\text{ plf}$, util $90.2\%$)
* **Chords & Collectors:** Continuous L4x4x3/8 (C1) assigned to all 20 candidate runs. Chords CH-S/CH-N carry maximum demand $57.95\text{ kips} \le \phi P_n = 92.66\text{ kips}$ ($62.5\%$ utilization). Drag struts DR-S1/DR-W2 carry maximum amplified demand $\Omega_0 P_u = 2.0 \times 4.54 = 9.07\text{ kips} \le 92.66\text{ kips}$.
* **Deflection & Drift Check:** Maximum design displacement from semi-rigid model across all 12 cases is $3.68\text{ in}$ (Case S12) and $3.50\text{ in}$ (Case S08), fully satisfying the Owner's permissible stability limit of $4.0\text{ in}$ (SDC-02 Section 7, ASCE 7-22 Section 12.12.2). Storey drift is under $0.25\text{ in} \ll \Delta_a = 5.04\text{ in}$.

## 6. Wall anchorage and the parapet cantilever

* **Parapet Cantilever Transfer:**
  Per SDC-02 Rev 2 Section 6 and FEMA P-2192-V1 Section 7.6.1 Step 1, the panels span vertically from foundation to roof deck ($h = 28.0\text{ ft}$) and cantilever to top of parapet ($H = 31.0\text{ ft}$).
  * Total weight tributary to roof: $w_{trib} = 100\text{ psf} \times H^2 / (2h) = 100 \times 31^2 / (2\times 28) = 1,716.07\text{ plf}$.
  * The lower 28 ft span contributes $100\text{ psf} \times 14\text{ ft} = 1,400.00\text{ plf}$.
  * The parapet above deck (height $3\text{ ft}$, weight $300\text{ plf}$, centroid at $y = 29.5\text{ ft}$) delivers reaction $R_{roof} = 300\text{ plf} \times 29.5 / 28.0 = 316.07\text{ plf}$ to the roof line.
* **Out-of-Plane Wall Anchorage Force:**
  Designed to ASCE/SEI 7-22 Section 12.11.2.1, Eq. 12.11-1:
  $$F_p = 0.4 S_{DS} k_a I_e W_p$$
  * Flexible diaphragm span $L_f$ per UFC 3-301-01 Figure 3-1 is $240\text{ ft}$ for S/N walls and $180\text{ ft}$ for W/E walls.
  * Amplification factor: $k_a = 1.0 + L_f / 100 \le 2.0$. For both directions, $1.0 + 1.8 = 2.8$ and $1.0 + 2.4 = 3.4$, which cap at $k_a = 2.0$.
  * Unit anchorage force: $F_p = 0.4 \times 0.44 \times 2.0 \times 1.25 \times 1,716.07\text{ plf} = 755.07\text{ plf}$ (governs over minimum $0.20 S_{DS} I_e W_p = 377.54\text{ plf}$).
* **Anchor Selection and Spacing:**
  WA1 joist seat anchors ($3/4\text{ in}$ rod, RPC-CAT-2026 Section 7) provide $T_n = 9.4\text{ kips}$, $\phi T_n = 0.75 \times 9.4 = 7.05\text{ kips}$ in LRFD.
  * Installed at $s = 8.0\text{ ft}$ uniform spacing along the walls.
  * Tension demand per anchor: $T_u = 755.07\text{ plf} \times 8.0\text{ ft} = 6.04\text{ kips} \le \phi T_n = 7.05\text{ kips}$ ($85.7\%$ utilization).
* **Subdiaphragms and Continuous Cross-Ties:**
  * South and North walls: subdiaphragm spans between N-S continuous ties at column lines ($40.0\text{ ft}$ span), depth $d = 24.0\text{ ft}$ (4 joist spaces). Aspect ratio $40.0 / 24.0 = 1.67:1 \le 2.5:1$ per ASCE 7-22 Section 12.11.2.2.1.
  * West and East walls: subdiaphragm spans between E-W continuous ties at column lines ($30.0\text{ ft}$ span), depth $d = 20.0\text{ ft}$. Aspect ratio $30.0 / 20.0 = 1.50:1 \le 2.5:1$.
  * Continuous cross-ties are provided across the full building width along column lines per Section 12.11.2.2.1 and S-201 Note 4.

## 7. Governing constraint per wall line

* **Wall Line S:** Governed by **in-plane shear** under Case S09 ($F_x = 103.73\text{ kips}$) and drag strut transfer across dock doors D-1 through D-5 ($14\text{ ft}$ and $15.5\text{ ft}$ clear openings). Base tie-down tension on pier S-P1 is $25.30\text{ kips} \le 33.0\text{ kips}$ (BA1 capacity).
* **Wall Line N:** Governed by **in-plane shear** under Case S09 ($F_x = 121.87\text{ kips}$; $117.29\text{ kips}$ in S02). Wall N is the stiffest line in the building ($k = 4,137.7\text{ kip/in}$) and attracts the largest E-W seismic shear. Panel base tie-down demand is $19.52\text{ kips} \le 33.0\text{ kips}$.
* **Wall Line W:** Governed by **base overturning tie-down tension** under Case S10 ($F_x = 119.60\text{ kips}$). Due to the $44\text{ ft}$ electrical yard opening EY-1, the resisting pier lengths are restricted ($12\text{ ft}$, $50\text{ ft}$, $70\text{ ft}$), resulting in the governing panel tie-down demand of $32.09\text{ kips} \le 33.0\text{ kips}$ ($97.2\%$ utilization of BA1).
* **Wall Line E:** Governed by **in-plane shear** under Case S08 ($F_x = 125.18\text{ kips}$). Wall E resists the majority of N-S shear due to center of mass shift from eastern RTUs. Panel tie-down demand is $29.43\text{ kips} \le 33.0\text{ kips}$ (BA1).

## 8. Cost

The installed cost of the delegated lateral scope is calculated in accordance with PROC-114 Rev 2 unit rates:

| Scope Item | Quantity | Unit Rate | Installed Cost (USD) |
|---|---|---|---|
| Deck Attachment Z1 | 3,200 sq ft (net) | $2.47 / sq ft (P5) | $7,904.00 |
| Deck Attachment Z2 | 2,400 sq ft (net) | $1.52 / sq ft (P3) | $3,648.00 |
| Deck Attachment Z3 | 3,600 sq ft (net) | $1.52 / sq ft (P3) | $5,472.00 |
| Deck Attachment Z4 | 3,600 sq ft (net) | $1.93 / sq ft (P4) | $6,948.00 |
| Deck Attachment Z5 | 3,600 sq ft (net) | $1.52 / sq ft (P3) | $5,472.00 |
| Deck Attachment Z6 | 3,400 sq ft (net) | $1.14 / sq ft (P2) | $3,876.00 |
| Deck Attachment Z7 | 3,200 sq ft (net) | $1.14 / sq ft (P2) | $3,648.00 |
| Deck Attachment Z8 | 3,600 sq ft (net) | $1.52 / sq ft (P3) | $5,472.00 |
| Deck Attachment Z9 | 3,600 sq ft (net) | $1.93 / sq ft (P4) | $6,948.00 |
| Deck Attachment Z10 | 3,000 sq ft (net) | $1.52 / sq ft (P3) | $4,560.00 |
| Deck Attachment Z11 | 2,400 sq ft (net) | $1.52 / sq ft (P3) | $3,648.00 |
| Deck Attachment Z12 | 3,600 sq ft (net) | $1.93 / sq ft (P4) | $6,948.00 |
| **Subtotal Deck Attachment** | **39,200 sq ft** | | **$64,544.00** |
| Perimeter Chords (CH-S/N/W/E) | 840 lin ft | $11.40 / ft (C1) | $9,576.00 |
| Opening Framing (OP-1 & OP-2) | 400 lin ft | $11.40 / ft (C1) | $4,560.00 |
| Drag Struts (DR-S/N/W/E) | 840 lin ft | $11.40 / ft (C1) | $9,576.00 |
| **Subtotal Chords & Collectors** | **2,080 lin ft** | | **$23,712.00** |
| Panel Joint Connectors | 0 (JC0 isolated) | $0.00 | $0.00 |
| Panel Base Tie-Downs | 81 panels | $520.00 / panel (BA1) | $42,120.00 |
| Wall-to-Diaphragm Anchors | 105 anchors (8' o.c.) | $96.00 / anchor (WA1) | $10,080.00 |
| SFRS Detailing Premium | 81 panels | $1,850.00 / panel | $149,850.00 |
| **TOTAL INSTALLED COST** | | | **$290,306.00** |
| **PROC-114 Capital Cap** | | | **$395,000.00** |
| **Budget Savings (Surplus)** | | | **$104,694.00** |

The installed cost of $290,306.00 is $104,694.00 (26.5%) below the hard capital cap of $395,000.00.

## 9. Alternatives rejected

1. **Special Precast Shear Walls:** Rejected because of the excessive detailing premium ($4,120 vs $1,850/panel, adding $183,870) and mandatory ductile connectors (RPC-60D @ $1,240 each). This would drive total cost to over $510,000, violating the PROC-114 budget cap. Intermediate precast is fully permitted in SDC D up to 40 ft height and costs far less.
2. **Ordinary Precast Shear Walls:** Rejected because UFC 3-301-01 Table 3-1 Item A.7 and ASCE 7-22 Table 12.2-1 strictly mark ordinary precast shear walls as Not Permitted (NP) in Seismic Design Category D.
3. **Panel Joint Connectors (JC1 / JC2):** Connectors were evaluated at 2 and 3 per joint (RPC-24 and RPC-40). While they slightly increase wall stiffness, isolated panel piers (JC0) already satisfy all drift limits, keep maximum diaphragm deflection to $3.68\text{ in} \le 4.0\text{ in}$, and keep panel base overturning tension to $32.09\text{ kips} \le 33.0\text{ kips}$ (BA1 capacity). Eliminating 116 connectors saves $44,660 to $70,760 with zero sacrifice in structural safety.
4. **Heavier Drag Struts (C2, C3, C4):** Evaluated W8x31 ($36.2/ft) and W12x53 ($62.5/ft). FEA envelope shows maximum amplified drag force is only $9.07\text{ kips}$, well within the $92.66\text{ kips}$ capacity of C1 (L4x4x3/8). Specifying C3 or C4 would add $20,000 to $42,000 with no structural benefit.
5. **Uniform High-Strength Deck Fastening (All P5 or All P4):** Using P5 across all 39,200 sq ft would cost $96,824 (an unnecessary $32,280 premium). Optimizing deck patterns by zone (P1/P2 in interior low-shear zones, P3/P4/P5 in high-shear perimeter zones) fully satisfies all shear flows while minimizing fastening labor.
6. **Heavier Base Tie-Downs (BA2 / BA3):** BA2 (4-#8 dowels, $910) and BA3 (4-#11 dowels, $1,680) were evaluated. Because isolated piers distribute lateral force among multiple panels along each segment, the peak panel tie-down demand is $32.09\text{ kips}$, which is within the $33.0\text{ kips}$ LRFD capacity of BA1 (2-#8 dowels). Standardizing on BA1 saves $31,590 to $93,960.
7. **Closer Wall Anchor Spacing (4 ft or 6 ft):** Evaluated WA1 at 4 ft and 6 ft. At 8 ft spacing, demand is $6.04\text{ kips} \le 7.05\text{ kips}$ capacity. Specifying 4 ft spacing would double anchor hardware and installation labor ($20,160 vs $10,080) unnecessarily.
