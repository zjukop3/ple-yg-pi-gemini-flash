# Building A2 Design Basis Narrative
**Northern Divide Data Campus — Building A2, Roof Diaphragm & Shear Wall Lateral Package**  
*Delegated Structural Lateral Design Submittal | Governing Standards: 2021 IBC / ASCE 7-16 | Load Basis: ASD (0.6W)*

---

## 1. Design Parameter Basis Table

| item | value | source |
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.8670 | ALTA-2025-77 benchmark BM-2 / Criteria 4.4 |
| q_h_psf | 28.74 | Criteria 4.2 / WT-2026-07 section 3 |
| screen_wall_top_ft | 36.00 | SR-2026-118 section 5.2 |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026 / Criteria 5.3 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 section 3.3 |
| omega_d | 2.35 | CDS-B36 Notes Note 2 |
| analysis_method | DIAPH-MT 1.0 semi-rigid membrane | EOR-NDDC-A2-S01 section 9 |
| mesh_level | L2 | EOR-NDDC-A2-S01 section 9.7 |

---

## 2. Governing Wind Scenario by Wall Line

| line | governing scenario |
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

*Note: In accordance with Section 1.6 of Submittal Specification 01 33 00 (and the explicit example `| S | W05 |`), the governing wind scenario for each exterior wall line is the cardinal scenario that produces maximum out-of-plane windward pressure and roof-level line load delivering lateral force into the diaphragm. Under in-plane shear wall reactions, the diaphragm reactions are maximized under transverse wind W01 for lines W and E2, under longitudinal wind W07 for line S, under longitudinal wind W03 for lines E and N2, and under oblique wind W08 for line N1.*

---

## 3. Conflict Resolution and Engineering Decisions

### 3.1 Structural Design Criteria Rev 0 vs Rev 2 (Governing Loads)
* **Conflict:** Revision 0 of the Structural Design Criteria (dated 3 May 2024) assumed a flat site ($K_{zt} = 1.00$), sea-level air density ($K_e = 1.00$), and a basic wind speed of $V = 105$ mph under Risk Category II.
* **Resolution:** On 11 June 2026, the Lewis and Clark County Building Division issued official letter NDDC-AHJ-014 mandating Risk Category III (due to the continuous-operation data hall serving critical communications) with $V = 115$ mph. Topographic wind study TS-2026-02 subsequently evaluated the valley bench terrain and established $K_{zt} = 1.19$ across the entire footprint. Survey ALTA-2025-77 documented site benchmark BM-2 at finished elevation 3,941.02 ft NAVD 88, resulting in $K_e = \exp(-0.0000362 \times 3941.02) = 0.8670$. Revision 2 of EOR-NDDC-A2-S01 formally incorporated these parameters. Revision 0 is superseded in full and was excluded from design calculations.

### 3.2 2024 Precast Fabrication Schedule vs 2026 As-Built Federated Model & Laser Scan
* **Conflict 1 (Mechanical Screen Wall Top Elevation):** The 2024 precast panel schedule (PC-S01) and preliminary elevations (PC-S02 Rev 1) listed all north wall panels at top elevation 31.00 ft. Terrestrial laser scan report SR-2026-118 and the 2026 Federated IFC Model establish that between stations $x = 96.0$ ft and $x = 168.0$ ft (panels N108, N109, N110, N111), the precast panels cantilever 8.00 ft above the roof deck to elevation 36.00 ft to form a solid mechanical screen wall.
* **Resolution 1:** Per Criteria Clause 5.3, the as-built federated model and roof line scan govern over superseded 2024 drawings. The screen wall top elevation of 36.00 ft was incorporated into the geometric take-off, panel gross dead weight calculations, and velocity pressure evaluation ($q_p = 30.31$ psf for the screen wall parapet vs $29.37$ psf for typical 31.0 ft parapets).
* **Conflict 2 (Panel S14 Field-Cut Opening):** Schedule PC-S01 recorded panel S14 as having no openings ('none'). The as-built model reflects opening S14-O1 (width 8.0 ft, head 12.0 ft, located between stations $s = 194.5$ ft and $s = 202.5$ ft), which was field-cut after erection for utility conduit penetration.
* **Resolution 2:** Opening S14-O1 was explicitly modeled. Applying Criteria Clause 5.4, the panel opening creates two vertical legs: a left leg from station 192.0 to 194.5 ft (width 2.5 ft) and a right leg from 202.5 to 204.0 ft (width 1.5 ft). Because the right leg width is less than the 2.0 ft threshold, it was neglected (assigned zero stiffness and zero in-plane shear capacity). The left leg was modeled as active pier P-S14-1 ($L = 2.5$ ft, $k = 4.29$ kip/in).

### 3.3 Diaphragm Analysis Idealization (Semi-Rigid vs Flexible)
* **Conflict:** The 2023 lateral study for Hall B (Building A1) utilized a tributary flexible diaphragm assumption.
* **Resolution:** Building A1 is a simple rectangle without re-entrant notches or screen walls, designed under preliminary criteria. Building A2 features an asymmetric footprint with a generator yard notch at $x = 180\text{--}240$ ft, $y = 140\text{--}180$ ft, and a mechanical well opening ($40' \times 30'$). Letter NDDC-AHJ-014 Item 3 and Criteria Section 9 explicitly reject tributary flexible and rigid diaphragm distributions. A rigorous semi-rigid 4-node bilinear membrane finite element formulation (DIAPH-MT 1.0) was implemented, incorporating framing axial stiffnesses ($EA_x = 2,900$ kip/ft from W24x62 girders, $EA_y = 13,920$ kip/ft from 26K9 joists), discrete chord/collector bar elements, and discrete pier springs. The formulation was verified against verification example VE-1, matching all published values to within 0.05%.

### 3.4 Deck Span and Joist Spacing in Mechanical Bay (Zone Z22)
* **Framing Condition:** Architectural drawing A-101 and framing plan S-201 show that joists in mechanical bay zone Z22 are doubled to 4'-0" on centre (deck span 4'-0"), whereas typical roof bays have joists at 5'-0" on centre (deck span 6'-0" east-west).
* **Resolution:** Note 4 of Diaphragm Design Manual CDS-B36 specifies that for a 4'-0" deck span, the tabulated shear stiffness $G'$ shall be multiplied by 1.15, while nominal shear strength remains unchanged. Accordingly, zone Z22 stiffness was adjusted to $G'_{\\text{used}} = 1.15 \\times G'_{\\text{tabulated}}$, correctly stiffening the mechanical bay membrane in the DIAPH-MT solver.

### 3.5 Re-entrant Corner Collector Drag and Panel E201 Base Connection
* **Observation:** In the semi-rigid analysis, collector line K-E2 drags transverse diaphragm shear into the generator yard west wall (Line E2), concentrating in panel E201 ($s = 140\text{--}150$ ft). Under scenario W01, panel E201 experiences an ASD shear of 15.40 kips, compared to the standard B1 base connection capacity of $1.40 \\times 10.0 = 14.00$ kips.
* **Resolution:** Per KRS-CN Clause 3.2, "the base connection is not adjustable in the field; a panel whose in-plane shear exceeds its B1 capacity requires a panel redesign, which is outside this package." This demand exceedance is documented for the Engineer of Record to facilitate foundation dowel redesign. To carry the roof-level shear transfer into panel E201, four Type E1 deck-to-panel embeds ($4 \\times 4.20 = 16.80$ kips capacity $> 15.40$ kips) are specified and scheduled.

### 3.6 Panel Overturning Stability and Tie-Down Assembly Specification
* **Stability Evaluation:** Under Criteria Clause 5.8, panel stability is evaluated under the ASD combination $0.6D + 0.6W$. Panel self-weight is computed on the gross area without opening deduction at 150 pcf. Overturning moment is $M_{OT} = V_{\\text{panel, ASD}} \\times 28.0$ ft, and dead load restoring moment is $M_R = 0.6 \\times W_{\\text{gross}} \\times (L / 2)$.
* **Resolution:** For 11 panels (including E201--E204 on Line E2, N201, N202, N204 on Line N2, N101 on Line N1, and S01, W01, W15), $M_{OT} > M_R$. Base tie-down assemblies (Type T1, 88 kips uplift capacity per KRS-CN Section 4) are provided at each end of these panels ($11 \\times \\$2,450 = \\$26,950$), ensuring complete overturning stability.

---

## 4. Trade Standardisation & Budget Compliance
* **Trade Standardisation (OBD 4.6):** Exactly three distinct 22-gauge deck types are specified across the entire roof:
  1. `D22-36/4-4` (Nominal 1,240 plf, ASD 527.7 plf) for perimeter zones Z11, Z13, Z43.
  2. `D22-36/7-2` (Nominal 1,610 plf, ASD 685.1 plf) for interior and field zones Z12, Z21, Z22, Z23, Z31, Z32, Z41, Z42.
  3. `D22-36/7-4` (Nominal 1,980 plf, ASD 842.6 plf) for re-entrant notch zone Z33.
  This satisfies the Owner's requirement of $\\le 4$ distinct deck types.
* **Cost Cap Compliance (OBD 4.7):** The total installed package cost is $\\$213,867.50$, representing a $31.0\\%$ margin below the certified cost cap of $\\$310,000.00$.
