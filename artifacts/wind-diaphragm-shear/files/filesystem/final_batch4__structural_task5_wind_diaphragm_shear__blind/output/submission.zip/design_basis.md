# Design Basis Narrative — Building A2 Lateral Package
**Northern Divide Data Campus, Building A2 · Lewis and Clark County, Montana**  
**Delegated Lateral Engineering Package · 14 August 2026**

---

## 1. Design Basis Parameters

The design of the roof diaphragm, chords, collectors, precast panels, and panel connections is established upon the governing project criteria, site surveys, geotechnical reports, and vendor data.

| item | value | source |
| Kzt | 1.19 | TS-2026-02 section 4 |
| Ke | 0.8671 | ALTA-2025-77 section 1 / EOR-NDDC-A2-S01 clause 4.4 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 clause 4.2 / ASCE 7-16 |
| screen_wall_top_ft | 36.00 | SR-2026-118 section 5.2 / NDDC-A2 Federated Model 2026 |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026 / PC-S02 Rev 2 Note 4 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 clause 3.3 |
| omega_d | 2.35 | CDS-B36 Table 3 Note 2 |
| analysis_method | DIAPH-MT 1.0 | EOR-NDDC-A2-S01 section 9 |
| mesh_level | L2 | EOR-NDDC-A2-S01 clause 9.7 |

---

## 2. Governing Wind Scenarios

The governing wind scenario for each perimeter shear wall line is established by the governing windward line load delivering lateral force into the roof deck diaphragm, as defined in EOR-NDDC-A2-S01 Section 6 and Specification 01 33 00 Section 1.6.

| line | governing scenario |
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

*Notes on Governing Loading:*
- **Line S (y = 0.0 ft):** Governed by Scenario W05 (180° South wind) producing the peak inward line load of 253.1 plf (ASD). The peak in-plane shear wall reaction occurs under longitudinal scenario W07 (33.71 kips ASD) when resisting overall east-west building shears.
- **Line E (x = 240.0 ft):** Governed by Scenario W03 (090° East wind) producing the peak inward line load of 253.4 plf (ASD). The peak in-plane shear wall reaction occurs under transverse scenario W05 (20.64 kips ASD).
- **Line N1 (y = 180.0 ft):** Governed by Scenario W01 (000° North wind) producing the peak inward line load of 321.8 plf (ASD), amplified by the solid precast mechanical screen wall between x = 96 ft and 168 ft. Peak reaction occurs under longitudinal scenario W07 (11.37 kips ASD).
- **Line W (x = 0.0 ft):** Governed by Scenario W07 (270° West wind) producing the peak inward line load of 252.3 plf (ASD). The peak in-plane shear wall reaction occurs under transverse scenario W01 (45.52 kips ASD).
- **Line N2 (y = 140.0 ft):** Governed by Scenario W01 (000° North wind) producing the peak inward line load of 265.7 plf (ASD) on the generator yard north elevation. Peak reaction occurs under scenario W03 (16.20 kips ASD).
- **Line E2 (x = 180.0 ft):** Governed by Scenario W07 (270° West wind) producing the peak line load of 264.0 plf (ASD) due to amplified aerodynamic suction within the re-entrant notch. The peak in-plane shear wall reaction occurs under scenario W01 (49.24 kips ASD).

---

## 3. Conflict Resolutions Between Issued Documents

During the engineering execution of this delegated lateral package, several dimensional, aerodynamic, and structural conflicts between the issued project documents were identified and resolved in strict accordance with the contract order of precedence.

### 3.1 Basic Wind Speed and Risk Category
- **Conflict:** The preliminary Structural Design Criteria Revision 0 (3 May 2024) referenced a basic wind speed of $V = 105\ mph}$ under Risk Category II.
- **Resolution:** The Authority Having Jurisdiction (Lewis and Clark County Building Division) issued binding letter `NDDC-AHJ-014` on 11 June 2026, mandating Risk Category III ($V = 115\ mph}$, Exposure C, $K_d = 0.85$) due to the facility's continuous critical communications mission. Structural Design Criteria Revision 2 (14 August 2026) adopted these parameters, and Revision 0 was formally superseded. The design is built strictly on $V = 115\ mph}$ (Risk Category III).

### 3.2 Topographic Factor ($K_{zt}$)
- **Conflict:** Preliminary design documents assumed level terrain ($K_{zt} = 1.00$).
- **Resolution:** The site occupies an escarpment bench rising 190 ft above the valley floor. Site-specific topographic wind study `TS-2026-02` (30 April 2026) established that speed-up effects govern, setting $K_{zt} = 1.19$ across the entire building footprint and height. Criteria Rev 2 formally incorporated $K_{zt} = 1.19$, superseding earlier assumptions.

### 3.3 Ground Elevation Factor ($K_e$)
- **Conflict:** Revision 0 took $K_e = 1.00$.
- **Resolution:** The ALTA land title and topographic survey `ALTA-2025-77` benchmark BM-2 establishes finished floor elevation FF-A2 at 3,940.0 ft above sea level. Applying the ASCE 7-16 ground elevation equation $K_e = \exp(-0.0000362 \* 3940.0) = 0.8671$. Criteria Rev 2 Clause 4.4 explicitly mandates that $K_e$ shall not be taken as 1.0. The value $K_e = 0.8671$ is used throughout.

### 3.4 Diaphragm Idealisation (Flexible vs. Semi-Rigid)
- **Conflict:** Preliminary campus work and the Building A1 lateral study (`HallB_Lateral_Study_2023`) utilised a flexible tributary diaphragm distribution.
- **Resolution:** Building A2 possesses a major re-entrant corner at the generator yard ($60\ ft} \times 40\ ft}$ notch), stiff precast perimeter panels of unequal lengths, and an unsymmetric mechanical screen wall. Both AHJ letter `NDDC-AHJ-014` and Criteria Rev 2 Section 9 strictly reject flexible or rigid diaphragm assumptions and require the semi-rigid finite element procedure `DIAPH-MT 1.0`. The diaphragm has been engineered exclusively using `DIAPH-MT 1.0`.

### 3.5 As-Built Mechanical Screen Wall Geometry
- **Conflict:** The 2024 Precast Panel Schedule (`PC-S01`) and architectural Rev A drawings showed a uniform parapet height of 31.00 ft (+3.0 ft above roof deck) along the entire North elevation.
- **Resolution:** Terrestrial laser scan report `SR-2026-118` and federated BIM model `NDDC-A2_Federated_Model_2026.ifc` confirmed that between $x = 96.0\ ft}$ and $x = 168.0\ ft}$ on Line N1 (panels N108, N109, N110, N111), the precast panels extend solid to elevation 36.00 ft (+8.0 ft above roof deck) to serve as an architectural screen wall for the mechanical yard. Per Criteria Rev 2 Clause 5.3 and 6.1, the as-built scan and federated model govern. Velocity pressure at the top of the screen wall is evaluated at $z = 36.0\ ft}$ ($q_p = 30.31\ psf}$), and the parapet cantilever delivers simple-beam reaction $R_{oof}} = p \* A \* (32.0 / 28.0)$ to the roof diaphragm.

### 3.6 Field-Cut Opening on Panel S14
- **Conflict:** Precast fabrication schedule `PC-S01` and panel drawing `PC-S02` recorded panel S14 ($x = 192.0$ to $204.0\ ft}$ on Line S) as solid with no openings.
- **Resolution:** As-built federated model `NDDC-A2_Federated_Model_2026.ifc` identifies an $8.0\ ft wide} \times 12.0\ ft high}$ personnel access opening (S14-O1) field-cut after erection between station $194.5\ ft}$ and $202.5\ ft}$. Per Criteria Clause 5.4, this opening divides S14 into a left leg of 2.5 ft width ($k = 5.70\ kip/in}$) and a right leg of 1.5 ft width. Because the right leg is narrower than 2.0 ft, it is neglected, assigned zero stiffness, and carries no in-plane shear. The left leg is scheduled as Pier P17, and the neglected leg as Pier P18 with $k = 0.0\ kip/in}$.

### 3.7 Precast Base Connection Shear Capacity at Re-Entrant Corner
- **Conflict:** Connection vendor data `KRS-CN` Clause 3.1 specifies a standard cast-in B1 panel base shear capacity of $1.40\ kips/ft}$ ($14.0\ kips}$ for a 10 ft panel). Due to significant shear drag through collectors K-N2 and K-E2 at the re-entrant corner under transverse wind (W01/W05), corner panel E201 experiences an ASD shear demand of $19.06\ kips}$, exceeding the standard $14.0\ kip}$ capacity.
- **Resolution:** KRS-CN Clause 3.2 establishes that the B1 base connection is not field-adjustable and any panel exceedance requires panel base redesign, which is outside this delegated package. The delegated lateral package flags this localized demand on panel E201 to the Engineer of Record for foundation dowel reinforcement or embedded shear lug enhancement.

---

## 4. Lateral Package Design Summary

1. **Roof Deck Optimization:** To comply with OBD Clause 4.6 (maximum 4 deck types across the campus), three gauge-22 deck configurations from `CDS-B36` are selected:
   - `D22-36/7-4` (nominal 1,980 plf, ASD capacity 842.6 plf, $G' = 32.6\ kip/in}$, cost $3.95/sf) deployed across interior bays Z21, Z22, Z23, Z31, Z32, Z33 to control shear drift.
   - `D22-36/7-2` (nominal 1,610 plf, ASD capacity 685.1 plf, $G' = 25.4\ kip/in}$, cost $3.62/sf) deployed in perimeter shear bays Z11, Z13, Z43.
   - `D22-36/4-2` (nominal 980 plf, ASD capacity 417.0 plf, $G' = 17.8\ kip/in}$, cost $3.05/sf) deployed in low-demand outer bays Z12, Z41, Z42.
2. **Deflection Performance:** Maximum diaphragm deflection relative to supports is $\Delta_X = 0.280\ in}$ and $\Delta_Y = 0.524\ in}$, both strictly within the campus limit of $0.550\ in}$. Maximum pier drift is $0.057\ in} \<= h/400 = 0.840\ in}$.
3. **Chords and Collectors:** All chord and collector lines utilize standard ASTM A572 Grade 50 flat plate:
   - Line C-E2 utilizes `PL4x3/8` (allowable compression $27.0\ kips} > 16.96\ kips}$ demand).
   - All other 11 lines utilize `PL3x3/8` (allowable compression $20.3\ kips} > 9.25\ kips}$ max demand).
4. **Connections & Stability:**
   - 140 Type E1 embeds are provided across the 63 panels (meeting both 8 ft spacing and shear transfer demands).
   - 13 panels require Type T1 tie-down assemblies under $0.6D + 0.6W$ overturning stability check.
5. **Cost Compliance:** Total installed lateral package cost is **$216,012.94**, comfortably below the owner's budget cap of **$310,000.00**.
